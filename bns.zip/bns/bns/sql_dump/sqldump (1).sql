-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Apr 25, 2019 at 03:28 AM
-- Server version: 5.7.23
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `craigslist`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE `account` (
  `email_id` varchar(30) NOT NULL,
  `password` varchar(400) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`email_id`, `password`) VALUES
('aaa@gmail.com', '448ed7416fce2cb66c285d182b1ba3df1e90016d'),
('admin@gmail.com', '7b902e6ff1db9f560443f2048974fd7d386975b0'),
('manisha@gmail.com', 'f988c245b3c789a608b34cd1b7c1b612542dbd09'),
('richa@gmail.com', 'f988c245b3c789a608b34cd1b7c1b612542dbd09'),
('test@gmail.com', '9bc34549d565d9505b287de0cd20ac77be1d3f2c'),
('xyz@gmail.com', 'f988c245b3c789a608b34cd1b7c1b612542dbd09'),
('yash.madane09@gmail.com', 'aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d'),
('yash.madane13@vit.edu', 'e1dce9cb7a817d82b4e312bbfa247ae59056c22a'),
('yash.madane@gmail.com', '448ed7416fce2cb66c285d182b1ba3df1e90016d'),
('yash1@gmail.com', 'f988c245b3c789a608b34cd1b7c1b612542dbd09'),
('yash2@gmail.com', 'f988c245b3c789a608b34cd1b7c1b612542dbd09'),
('yash@gmail.com', '8b2b3f84a09e4906bb5aa57031a02aad6ca85447');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `email_id` varchar(30) NOT NULL,
  `firstname` varchar(30) NOT NULL,
  `lastname` varchar(30) NOT NULL,
  `phone_no` varchar(30) NOT NULL,
  `street` varchar(30) NOT NULL,
  `city` varchar(30) NOT NULL,
  `state` varchar(30) NOT NULL,
  `country` varchar(30) NOT NULL,
  `rating` int(1) NOT NULL,
  `isAdmin` tinyint(1) NOT NULL,
  `zipcode` varchar(20) DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`email_id`, `firstname`, `lastname`, `phone_no`, `street`, `city`, `state`, `country`, `rating`, `isAdmin`, `zipcode`, `is_deleted`) VALUES
('aaa@gmail.com', 'Test', 'Test', '6823869802', '17817 Coit Rd', 'Dallas', 'TX', 'United States', 0, 0, '75252', NULL),
('admin@gmail.com', 'Admin', 'Admin', '16823869802', '17817 Coit Rd', 'Dallas', 'TX', 'United States', 0, 1, '75252', NULL),
('manisha@gmail.com', 'Manisha', 'Prasad', '888888888', '7816 McCallum Blvd', 'Dallas', 'TX', 'USA', 0, 0, '75252', NULL),
('richa@gmail.com', 'Richa', 'A', '000000012', 'Frankford', 'Dallas', 'TX', 'USA', 0, 0, '75252', NULL),
('test@gmail.com', 'Yash', 'Madane', '16823869802', '17817 Coit Rd', 'Dallas', 'TX', 'United States', 0, 0, '75252', NULL),
('xyz@gmail.com', 'Test', 'Test', '6823869802', '17817 Coit Rd', 'Dallas', 'TX', 'United States', 0, 0, '75252', NULL),
('yash.madane09@gmail.com', 'Yash', 'Madane', '16823869802', '17817 Coit Rd', 'Dallas', 'TX', 'United States', 0, 0, '75252', NULL),
('yash.madane13@vit.edu', 'Yash', 'Madane', '16823869802', '17817 Coit Rd', 'Dallas', 'TX', 'United States', 0, 0, '75252', NULL),
('yash.madane@gmail.com', 'Yash', 'Madane', '899999999', '17817 Coit Road ,Dallas, 6106', 'Dallas', 'Texas', 'United States', 0, 0, '75252', NULL),
('yash1@gmail.com', 'Yash', 'M', '99999999', '999 Segu', 'Little Rock', 'AR', 'USA', 0, 0, '9999', NULL),
('yash2@gmail.com', 'Yash', 'Madane', '16823869802', '17817 Coit Rd', 'Dallas', 'TX', 'United States', 0, 0, '75252', NULL),
('yash@gmail.com', 'Yash dummy', '', '2145173549', '7825 McCallumBlvd', 'Dallas', 'TX ', 'US', 0, 0, '75252', 1);

-- --------------------------------------------------------

--
-- Table structure for table `utility`
--

CREATE TABLE `utility` (
  `utility_id` bigint(30) NOT NULL,
  `name` varchar(30) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `isAvailable` tinyint(1) DEFAULT NULL,
  `email_id` varchar(30) DEFAULT NULL,
  `city` varchar(30) DEFAULT NULL,
  `street` varchar(30) DEFAULT NULL,
  `state` varchar(30) DEFAULT NULL,
  `country` varchar(30) DEFAULT NULL,
  `rating` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `post_date` date DEFAULT NULL,
  `description` varchar(1500) DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT '0',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `utility`
--

INSERT INTO `utility` (`utility_id`, `name`, `category_id`, `isAvailable`, `email_id`, `city`, `street`, `state`, `country`, `rating`, `price`, `post_date`, `description`, `is_deleted`, `timestamp`) VALUES
(230, 'House', 2, 1, 'test@gmail.com', 'Dallas', '17817 Coit Rd, 6106', 'TX', 'United States', NULL, 5000, NULL, 'Brief description...\r\n              Available in Manhttan', 1, '2019-04-23 23:04:54'),
(231, 'Richardson EstATE', 2, 1, 'yash.madane@gmail.com', 'Richardson', '7777 Richardson Avenue', 'Texas', 'USA', NULL, 5000, NULL, 'Brief description...\r\n              In the lush meadows of Richardson', 0, '2019-04-23 23:15:13'),
(232, 'Corvett', 1, 1, 'yash.madane@gmail.com', 'Miami', 'Miami ST', 'Florida', 'USA', NULL, 150000, NULL, 'Brief description...\r\n              The most luxurious house in Miami', 0, '2019-04-23 23:16:30'),
(233, 'Batman tshirt', 1, 1, 'yash.madane@gmail.com', 'Dallas', '777 Texas Dr', 'TX', 'USA', NULL, 35, NULL, 'Brief description...\r\n              Cool original signed batman image', 0, '2019-04-23 23:21:59'),
(234, 'Painting', 1, 1, 'yash.madane@gmail.com', 'Los Angeles', '666 Sunshine Blvd', 'CA', 'USA', NULL, 20000, NULL, 'Brief description...\r\n              Originial Jackson Pollock painting', 0, '2019-04-23 23:24:14'),
(235, 'Toy Duck', 1, 1, 'manisha@gmail.com', 'San Francisco', '8888 Sim Avenue', 'CA', 'USA', NULL, 10, NULL, 'Brief description...\r\n              A toy duck for babies', 0, '2019-04-23 23:27:33'),
(236, 'Palencia', 1, 1, 'manisha@gmail.com', 'Dallas', '17817 Coit Road ', 'TX', 'United States', NULL, 1460, NULL, 'Brief description...\r\n              A beautiful lush community housing', 0, '2019-04-23 23:29:23'),
(237, 'Frankford', 2, 1, 'manisha@gmail.com', 'Dallas', 'Frankford St', 'TX', 'USA', NULL, 1800, NULL, 'Brief description...\r\n              Beautiful Frankford house for Sale', 0, '2019-04-23 23:33:03'),
(238, 'WWE belt', 1, 1, 'manisha@gmail.com', 'San Francisco', '3929 SF Avenue', 'CA', 'USA', NULL, 500, NULL, 'WWE championship belt             ', 0, '2019-04-23 23:34:58'),
(239, 'Spinner Belt', 1, 1, 'manisha@gmail.com', 'San Jose', 'Seguoia Dr', 'CA', 'USA', NULL, 4000, NULL, 'Originial Spinner Belt', 0, '2019-04-23 23:36:47'),
(240, 'Chatham Reflections', 2, 1, 'manisha@gmail.com', 'Dallas', '7815 McCallum Blvd', 'TX', 'USA', NULL, 1100, NULL, '     Cheap student housing', 0, '2019-04-23 23:38:17'),
(241, 'Web Hosting', 1, 1, 'richa@gmail.com', 'SItka', 'Secret Street', 'Alaska ', 'USA', NULL, 900, NULL, 'Hosting available', 0, '2019-04-23 23:43:06'),
(242, 'Avengers DVD', 1, 1, 'richa@gmail.com', 'Dallas', '17817 Coit Rd, 6106', 'TX', 'United States', NULL, 70, NULL, 'Avengers Series', 0, '2019-04-23 23:44:02'),
(243, 'Christopher Robin DVD', 1, 1, 'richa@gmail.com', 'Dallas', '17817 Coit Rd, 6106', 'TX', 'United States', NULL, 70, NULL, 'Christopher Robin DVD            ', 0, '2019-04-23 23:44:57'),
(244, 'Ashwood', 2, 1, 'richa@gmail.com', 'Dallas', '7650 McCallum Bkcd', 'TX', 'USA', NULL, 1300, NULL, 'Student Housinf', 0, '2019-04-23 23:46:17'),
(245, 'Beverly hills', 2, 1, 'richa@gmail.com', 'LA', 'Hoolywood Blvd', 'CA', 'USA', NULL, 150000, NULL, 'beverly hills house for lease', 0, '2019-04-23 23:48:25'),
(246, 'malibu', 2, 1, 'richa@gmail.com', 'LA', 'Malibu', 'CA', 'USA', NULL, 5000, NULL, 'Malibu Beach house', 0, '2019-04-23 23:52:07'),
(247, 'Gym Equipment', 1, 1, 'richa@gmail.com', 'Dallas', '17817 Coit Road ,Dallas, 6106', 'TX', 'USA', NULL, 40, NULL, 'Good gym equipment', 0, '2019-04-23 23:54:48'),
(248, 'Spotify', 1, 1, 'richa@gmail.com', 'Kancuk', '222', 'AR', 'USA', NULL, 1, NULL, 'Spotify account for sale', 0, '2019-04-24 00:02:27'),
(249, 'WWE tickets', 1, 1, 'yash2@gmail.com', 'Pune', '759/11,Fulora,Deccan', 'Maharashtra', 'India', NULL, 200, NULL, 'WWE tickets for sale', 0, '2019-04-24 00:06:36'),
(250, 'Matlab account', 1, 1, 'yash2@gmail.com', 'Dallas', '17817 Coit Road Apt 6106', 'TX', 'United States', NULL, 100, NULL, 'Matlab account for sale', 0, '2019-04-24 00:07:36'),
(251, 'Marquis', 2, 1, 'yash2@gmail.com', 'Dallas', 'East side', 'TX', 'USA', NULL, 1800, NULL, 'Brief description...\r\n              Marquis student housing', 0, '2019-04-24 00:08:33'),
(252, 'Estates ', 2, 1, 'yash2@gmail.com', 'Dallas', 'East side', 'TX', 'USA', NULL, 1800, NULL, 'Exoensive student housing', 0, '2019-04-24 00:10:38'),
(253, 'Tennis', 1, 1, 'yash2@gmail.com', 'Dallas', '17817 Coit Rd, 6106', 'TX', 'United States', NULL, 10, NULL, 'Walmart Tennis racquet for sale', 0, '2019-04-24 00:17:47'),
(254, 'Nike Shoes', 1, 1, 'yash2@gmail.com', 'Dallas', '7815 McCallum Blvd', 'TX', 'USA', NULL, 30, NULL, 'Nike shoes for sale\r\n              ', 0, '2019-04-24 00:19:02'),
(255, 'Marriot room', 2, 1, 'yash2@gmail.com', 'Natick', '1111 Natick', 'MA', 'USA', NULL, 1000, NULL, 'Room for one night            ', 0, '2019-04-24 00:20:01'),
(256, 'superdry hoodie', 1, 1, 'yash2@gmail.com', 'Dallas', '17817 Coit Rd, 6106', 'TX', 'United States', NULL, 100, NULL, 'New superdry hoodie for sale', 0, '2019-04-24 00:22:57'),
(257, 'Samsung s9', 4, 1, 'aaa@gmail.com', 'Dallas', '17817 Coit Rd, 6106', 'TX', 'United States', NULL, 500, NULL, 'Amazing mobile for sale', 0, '2019-04-25 01:33:02'),
(258, 'Stereo for sale', 4, 1, 'aaa@gmail.com', 'San Francisco', '759/11,Fulora,Deccan Gymkhana', 'CA', 'USA', NULL, 8000, NULL, 'This is an amazing homeset . 3 months old', 0, '2019-04-25 01:35:28'),
(259, 'Old mobile for sale', 4, 1, 'aaa@gmail.com', 'Dallas', '17817 Coit Rd', 'TX', 'United States', NULL, 30, NULL, 'Broken screen', 0, '2019-04-25 01:42:05'),
(260, 'Blackberry for sale', 4, 1, 'aaa@gmail.com', 'Dallas', '17817 Coit Rd', 'TX', 'United States', NULL, 120, NULL, 'Broken blackberry trackpad', 0, '2019-04-25 01:42:56'),
(261, 'Samsung in good condition', 4, 1, 'aaa@gmail.com', 'Dallas', '17817 Coit Rd', 'TX', 'United States', NULL, 300, NULL, 'Samsung phone in good condition', 0, '2019-04-25 01:43:51'),
(262, 'Phone used for 1 month', 4, 1, 'aaa@gmail.com', 'Dallas', '17817 Coit Rd, 6106', 'TX', 'United States', NULL, 300, NULL, 'Great phone', 0, '2019-04-25 01:47:05'),
(263, 'Great car for sale', 3, 1, 'manisha@gmail.com', 'Dallas', '17817 Coit Rd, 6106', 'TX', 'United States', NULL, 60000, NULL, 'Car new 2 months old', 0, '2019-04-25 01:52:53'),
(264, 'BMW for sale', 3, 1, 'manisha@gmail.com', 'Dallas', '17817 Coit Rd', 'TX', 'United States', NULL, 50000, NULL, 'Great new X5 for sale', 0, '2019-04-25 01:54:19'),
(265, 'Recent bought car', 4, 1, 'manisha@gmail.com', 'Dallas', '17817 Coit Rd, 6106', 'TX', 'United States', NULL, 34000, NULL, 'A good Audi 9 months old', 1, '2019-04-25 01:55:37'),
(266, 'Recent bought car', 3, 1, 'manisha@gmail.com', 'Dallas', '17817 Coit Rd, 6106', 'TX', 'United States', NULL, 40000, NULL, 'Amazing car', 0, '2019-04-25 01:57:22'),
(267, 'Car in great condition', 3, 1, 'manisha@gmail.com', 'Dallas', '17817 Coit Rd, 6106', 'TX', 'United States', NULL, 1000, NULL, 'Hurry up. 2 bidders already there', 0, '2019-04-25 01:59:44');

-- --------------------------------------------------------

--
-- Table structure for table `utility_category`
--

CREATE TABLE `utility_category` (
  `category_id` int(1) NOT NULL,
  `name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `utility_category`
--

INSERT INTO `utility_category` (`category_id`, `name`) VALUES
(1, 'For Sale'),
(2, 'Housing'),
(3, 'Vehicles'),
(4, 'Technology');

-- --------------------------------------------------------

--
-- Table structure for table `utility_image`
--

CREATE TABLE `utility_image` (
  `utility_id` bigint(30) NOT NULL,
  `image_path` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `utility_image`
--

INSERT INTO `utility_image` (`utility_id`, `image_path`) VALUES
(230, '../php/product-images/test@gmail.com/5912burger-2.jpg'),
(231, '../php/product-images/yash.madane@gmail.com/937rich1.jpeg'),
(232, '../php/product-images/yash.madane@gmail.com/4305miami.jpg'),
(233, '../php/product-images/yash.madane@gmail.com/8074batman.jpeg'),
(234, '../php/product-images/yash.madane@gmail.com/1449paint.jpg'),
(235, '../php/product-images/manisha@gmail.com/7838duck.jpeg'),
(236, '../php/product-images/manisha@gmail.com/2471palencia.jpeg'),
(237, '../php/product-images/manisha@gmail.com/3041frankford.jpg'),
(238, '../php/product-images/manisha@gmail.com/2830belt.jpeg'),
(239, '../php/product-images/manisha@gmail.com/8773spinner.jpg'),
(240, '../php/product-images/manisha@gmail.com/231chatham.jpeg'),
(241, '../php/product-images/richa@gmail.com/1682hosting.jpeg'),
(242, '../php/product-images/richa@gmail.com/6861avengers.jpg'),
(243, '../php/product-images/richa@gmail.com/8076robin.jpg'),
(244, '../php/product-images/richa@gmail.com/9363ashwood.jpg'),
(245, '../php/product-images/richa@gmail.com/3556beverly.jpg'),
(246, '../php/product-images/richa@gmail.com/1032malibu.jpg'),
(247, '../php/product-images/richa@gmail.com/6699gym.jpeg'),
(248, '../php/product-images/richa@gmail.com/3930spotify.png'),
(249, '../php/product-images/yash2@gmail.com/3523ticket.jpg'),
(250, '../php/product-images/yash2@gmail.com/9098matl.jpg'),
(251, '../php/product-images/yash2@gmail.com/3382marquis.jpeg'),
(252, '../php/product-images/yash2@gmail.com/5948estates.jpg'),
(253, '../php/product-images/yash2@gmail.com/6202tennis.jpeg'),
(254, '../php/product-images/yash2@gmail.com/2741nike.jpg'),
(255, '../php/product-images/yash2@gmail.com/124marriot.jpg'),
(256, '../php/product-images/yash2@gmail.com/1579superdry.jpg'),
(257, '../php/product-images/aaa@gmail.com/mobile.png'),
(258, '../php/product-images/aaa@gmail.com/electronics.png'),
(259, '../php/product-images/aaa@gmail.com/m2.jpg'),
(260, '../php/product-images/aaa@gmail.com/p4.jpg'),
(261, '../php/product-images/aaa@gmail.com/m10.jpg'),
(262, '../php/product-images/aaa@gmail.com/ss3.jpg'),
(263, '../php/product-images/manisha@gmail.com/c10.jpg'),
(264, '../php/product-images/manisha@gmail.com/c7.jpg'),
(265, '../php/product-images/manisha@gmail.com/c9.jpg'),
(266, '../php/product-images/manisha@gmail.com/c12.jpg'),
(267, '../php/product-images/manisha@gmail.com/c13.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--

CREATE TABLE `wishlist` (
  `email_id` varchar(30) NOT NULL,
  `utility_id` bigint(30) NOT NULL,
  `timestamp` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wishlist`
--

INSERT INTO `wishlist` (`email_id`, `utility_id`, `timestamp`) VALUES
('aaa@gmail.com', 254, '2019-04-25 01:45:08.756469'),
('aaa@gmail.com', 256, '2019-04-25 01:45:20.388952'),
('manisha@gmail.com', 239, '2019-04-25 01:50:23.621088'),
('richa@gmail.com', 245, '2019-04-24 00:01:06.205161'),
('richa@gmail.com', 246, '2019-04-24 00:01:05.069152'),
('richa@gmail.com', 247, '2019-04-24 00:01:07.568870');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`email_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`email_id`);

--
-- Indexes for table `utility`
--
ALTER TABLE `utility`
  ADD PRIMARY KEY (`utility_id`),
  ADD KEY `category_id` (`category_id`),
  ADD KEY `email_id` (`email_id`);

--
-- Indexes for table `utility_category`
--
ALTER TABLE `utility_category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `utility_image`
--
ALTER TABLE `utility_image`
  ADD PRIMARY KEY (`utility_id`,`image_path`);

--
-- Indexes for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD PRIMARY KEY (`email_id`,`utility_id`),
  ADD KEY `utility_id` (`utility_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `utility`
--
ALTER TABLE `utility`
  MODIFY `utility_id` bigint(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=268;

--
-- AUTO_INCREMENT for table `utility_image`
--
ALTER TABLE `utility_image`
  MODIFY `utility_id` bigint(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=268;

--
-- AUTO_INCREMENT for table `wishlist`
--
ALTER TABLE `wishlist`
  MODIFY `utility_id` bigint(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=257;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `account`
--
ALTER TABLE `account`
  ADD CONSTRAINT `account_ibfk_1` FOREIGN KEY (`email_id`) REFERENCES `user` (`email_id`);

--
-- Constraints for table `utility`
--
ALTER TABLE `utility`
  ADD CONSTRAINT `utility_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `utility_category` (`category_id`),
  ADD CONSTRAINT `utility_ibfk_2` FOREIGN KEY (`email_id`) REFERENCES `user` (`email_id`);

--
-- Constraints for table `utility_image`
--
ALTER TABLE `utility_image`
  ADD CONSTRAINT `utility_image_idfk_1` FOREIGN KEY (`utility_id`) REFERENCES `utility` (`utility_id`);

--
-- Constraints for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD CONSTRAINT `wishlist_ibfk_1` FOREIGN KEY (`email_id`) REFERENCES `user` (`email_id`),
  ADD CONSTRAINT `wishlist_ibfk_2` FOREIGN KEY (`utility_id`) REFERENCES `utility` (`utility_id`);