<?php

	// Create connection
	$conn = mysqli_connect("localhost", "root", "", "craigslist");
	// Check connection
	if (!$conn) {
	    die("Connection failed: " . mysqli_connect_error());
	}


	if ($_SERVER['REQUEST_METHOD'] === 'POST') {
		$email = $_POST['email'];
		$pwd = sha1($_POST['password']);

		$verify_pwd = "SELECT * FROM account WHERE email_id='".$email."' AND password='".$pwd."';";

		$res = mysqli_query($conn, $verify_pwd);

		if(mysqli_num_rows($res) == 0){
			echo "<script type='text/javascript'>alert('Username or Password Incorrect');</script>";
			header("refresh:0;../html/login.html");
		}

		else{
			$admin = "SELECT * FROM user WHERE email_id='".$email."'";
			$res = mysqli_query($conn, $admin);

			$row = mysqli_fetch_assoc($res);
			
			if($row['isAdmin'] == 1){
				session_start();
				$_SESSION["email_id"] = $email;
				$_SESSION["isAdmin"] = 1;
				$_SESSION["firstname"] = $row['firstname'];
				//header("Location: ../php/view_users.php");
				header("Location: ../html/homepage.php");
			}else if($row['is_deleted'] == 1){
				header("refresh:0;../html/login.html");
				echo "<script type='text/javascript'>alert('Account disabled');</script>";
			}
			else
			{
				session_start();
				$_SESSION["email_id"] = $email;
				$_SESSION["firstname"] = $row['firstname'];
				header("Location: ../html/homepage.php");
			}
		}	
	}
?>