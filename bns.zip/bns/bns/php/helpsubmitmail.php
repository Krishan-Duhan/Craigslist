<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $message = $_POST['message'];
    $mailto = "testwpluser@gmail.com";
    $email_id = $mailto;
    $mailSub = "Help Support: Query";//$_POST['mail_sub'];
    $mailMsg = $message;

   require '../PHPMailer-master/PHPMailerAutoload.php';
   $mail = new PHPMailer();
   $mail ->IsSmtp();
   $mail ->SMTPDebug = 0;
   $mail ->SMTPAuth = true;
   $mail ->SMTPSecure = 'ssl';
   $mail ->Host = "smtp.gmail.com";
   $mail ->Port = 465; // or 587
   $mail ->IsHTML(true);
   $mail ->Username = "testwpluser@gmail.com";
   $mail ->Password = "Qwerty123#";
   $mail ->SetFrom("testwpluser@gmail.com");
   $mail ->Subject = $mailSub;
   $mail ->Body = $mailMsg;
   $mail ->AddAddress($mailto);

   if(!$mail->Send())
   {
       echo "Mail Not Sent";
   }
   else
   {
       echo "Sending email, please check you inbox";

       // echo "Adding to the cart";
          $message = "We received your feedback.";
        echo "<script type='text/javascript'>alert('$message');</script>";
          // header("Location: ../html/homepage.php");
          header("refresh:0;../html/index.html");
          exit();
   }
}




   

