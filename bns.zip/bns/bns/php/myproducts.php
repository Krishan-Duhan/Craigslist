<?php
    if(!isset($_SESSION)) 
    { 
        session_start(); 
    } 
    if(!isset($_SESSION['email_id'])){
      header("Location: ../html/login.html");
    }
    $_SESSION['delHome'] = 0;

     $servername = "localhost";
      $username = "root";
      $password = "";
      $dbname = "craigslist";
      $limit = 4;

      // Create connection
      $conn = mysqli_connect($servername, $username, $password, $dbname);
      
      // Check connection
      if (!$conn) {
          die("Connection failed: " . mysqli_connect_error());
      }
?>
<!DOCTYPE html>
<html>
  <head>
<title>BnS: Add a Product</title>
<link rel="stylesheet" href="../css/bootstrap.min.css"><!-- bootstrap-CSS -->
<link rel="stylesheet" href="../css/bootstrap-select.css"><!-- bootstrap-select-CSS -->
<link href="../css/style.css" rel="stylesheet" type="text/css" media="all" /><!-- style.css -->
<link rel="stylesheet" href="../css/font-awesome.min.css" /><!-- fontawesome-CSS -->
<link rel="stylesheet" href="../css/menu_sideslide.css" type="text/css" media="all"><!-- Navigation-CSS -->
<!-- meta tags -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Resale Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //meta tags -->
<!--fonts-->
<link href='//fonts.googleapis.com/css?family=Ubuntu+Condensed' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<!--//fonts-->  
<!-- js -->
<script type="text/javascript" src="../js/jquery.min.js"></script>
<!-- js -->
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="../js/bootstrap.js"></script>
<script src="../js/bootstrap-select.js"></script>
<script>
  $(document).ready(function () {
    var mySelect = $('#first-disabled2');

    $('#special').on('click', function () {
      mySelect.find('option:selected').prop('disabled', true);
      mySelect.selectpicker('refresh');
    });

    $('#special2').on('click', function () {
      mySelect.find('option:disabled').prop('disabled', false);
      mySelect.selectpicker('refresh');
    });

    $('#basic2').selectpicker({
      liveSearch: true,
      maxOptions: 1
    });
  });
</script>
<!-- language-select -->
<script type="text/javascript" src="../js/jquery.leanModal.min.js"></script>
<link href="../css/jquery.uls.css" rel="stylesheet"/>
<link href="../css/jquery.uls.grid.css" rel="stylesheet"/>
<link href="../css/jquery.uls.lcd.css" rel="stylesheet"/>
<!-- Source -->
<script src="../js/jquery.uls.data.js"></script>
<script src="../js/jquery.uls.data.utils.js"></script>
<script src="../js/jquery.uls.lcd.js"></script>
<script src="../js/jquery.uls.languagefilter.js"></script>
<script src="../js/jquery.uls.regionfilter.js"></script>
<script src="../js/jquery.uls.core.js"></script>
<script>
      $( document ).ready( function() {
        $( '.uls-trigger' ).uls( {
          onSelect : function( language ) {
            var languageName = $.uls.data.getAutonym( language );
            $( '.uls-trigger' ).text( languageName );
          },
          quickList: ['en', 'hi', 'he', 'ml', 'ta', 'fr'] //FIXME
        } );
      } );
    </script>
<!-- //language-select -->
</head>
  <body>
  	<div class="agiletopbar">
      <div class="wthreenavigation">
        <div class="menu-wrap">
        <nav class="menu">
          <div class="icon-list">
            <a href="../html/homepage.php"><i class="fa fa-fw fa-mobile"></i><span>Products</span></a>
            <a href="../php/mywishlist.php"><i class="fa fa-fw fa-laptop"></i><span>Wishlist</span></a>
            <a href="../html/utility.php"><i class="fa fa-fw fa-car"></i><span>Add Product</span></a>
            <a href="../html/myproducts.php"><i class="fa fa-fw fa-motorcycle"></i><span>My Products</span></a>
                <?php
            if(isset($_SESSION['isAdmin']) && $_SESSION['isAdmin']==1){
          ?>
            <a href="../php/view_users.php"><i class="fa fa-fw fa-wheelchair"></i><span>View Users</span></a>  <?php
          }
          ?>
          </div>
        </nav>
        <button class="close-button" id="close-button">Close Menu</button>
      </div>
      <button class="menu-button" id="open-button"> </button>
      </div>
      <div class="clearfix"></div>
    </div>

  <header>
    <div class="w3ls-header"><!--header-one--> 
      <div class="w3ls-header-right">
        <ul>
          <li class="dropdown head-dpdn">
            <a href="../php/destroysession.php" aria-expanded="false"><i class="fa fa-user" aria-hidden="true"></i> Logout</a>

          <?php
            if(isset($_SESSION['isAdmin']) && $_SESSION['isAdmin']==1){
          ?>
          <script type="text/javascript"> $("a.fa fa-user").css("width","12%");</script>
          <?php
          }?>
          </li>
          <li class="dropdown head-dpdn">
            <a href="help.html"><i class="fa fa-question-circle" aria-hidden="true"></i> Help</a>
          </li>
          <li class="dropdown head-dpdn">
            <a href="#"><span class="active uls-trigger"><i class="fa fa-language" aria-hidden="true"></i>languages</span></a>
          </li>
          <li class="dropdown head-dpdn">
            <div class="header-right">      
  <!-- Large modal -->
      <div class="selectregion">
        <button class="btn btn-primary" data-toggle="modal" data-target="#myModal">
        <i class="fa fa-globe" aria-hidden="true"></i>Select City</button>
          <div class="modal fade" id="myModal" tabindex="-1" role="dialog"  
          aria-hidden="true">
            <div class="modal-dialog modal-lg">
              <div class="modal-content">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                    &times;</button>
                  <h4 class="modal-title" id="myModalLabel">
                    Please Choose Your Location</h4>
                </div>
                <div class="modal-body">
                   <form class="form-horizontal" action="#" method="get">
                    <div class="form-group">
                      <select id="basic2" class="show-tick form-control" multiple>
                        <optgroup label="Popular Cities">
                          <option selected style="display:none;color:#eee;">Select City</option>
                          <option>Birmingham</option>
                          <option>Anchorage</option>
                          <option>Phoenix</option>
                          <option>Little Rock</option>
                          <option>Los Angeles</option>
                          <option>Denver</option>
                          <option>Bridgeport</option>
                          <option>Wilmington</option>
                          <option>Jacksonville</option>
                          <option>Atlanta</option>
                          <option>Honolulu</option>
                          <option>Boise</option>
                          <option>Chicago</option>
                          <option>Indianapolis</option>
                        </optgroup>
                        <optgroup label="More Cities">
                          <optgroup label="Alabama">
                            <option>Birmingham</option>
                            <option>Montgomery</option>
                            <option>Mobile</option>
                            <option>Huntsville</option>
                            <option>Tuscaloosa</option>
                          </optgroup>
                          <optgroup label="Alaska">
                            <option>Anchorage</option>
                            <option>Fairbanks</option>
                            <option>Juneau</option>
                            <option>Sitka</option>
                            <option>Ketchikan</option>
                          </optgroup>
                          <optgroup label="Arizona">
                            <option>Phoenix</option>
                            <option>Tucson</option>
                            <option>Mesa</option>
                            <option>Chandler</option>
                            <option>Glendale</option>
                          </optgroup>
                          <optgroup label="Arkansas">
                            <option>Little Rock</option>
                            <option>Fort Smith</option>
                            <option>Fayetteville</option>
                            <option>Springdale</option>
                            <option>Jonesboro</option>
                          </optgroup>
                          <optgroup label="California">
                            <option>Los Angeles</option>
                            <option>San Diego</option>
                            <option>San Jose</option>
                            <option>San Francisco</option>
                            <option>Fresno</option>
                          </optgroup>
                          <optgroup label="Colorado">
                            <option>Denver</option>
                            <option>Colorado</option>
                            <option>Aurora</option>
                            <option>Fort Collins</option>
                            <option>Lakewood</option>
                          </optgroup>
                          <optgroup label="Connecticut">
                            <option>Bridgeport</option>
                            <option>New Haven</option>
                            <option>Hartford</option>
                            <option>Stamford</option>
                            <option>Waterbury</option>
                          </optgroup>
                          <optgroup label="Delaware">
                            <option>Wilmington</option>
                            <option>Dover</option>
                            <option>Newark</option>
                            <option>Bear</option>
                            <option>Middletown</option>
                          </optgroup>
                          <optgroup label="Florida">
                            <option>Jacksonville</option>
                            <option>Miami</option>
                            <option>Tampa</option>
                            <option>St. Petersburg</option>
                            <option>Orlando</option>
                          </optgroup>
                          <optgroup label="Georgia">
                            <option>Atlanta</option>
                            <option>Augusta</option>
                            <option>Columbus</option>
                            <option>Savannah</option>
                            <option>Athens</option>
                          </optgroup>
                          <optgroup label="Hawaii">
                            <option>Honolulu</option>
                            <option>Pearl City</option>
                            <option>Hilo</option>
                            <option>Kailua</option>
                            <option>Waipahu</option>
                          </optgroup>
                          <optgroup label="Idaho">
                            <option>Boise</option>
                            <option>Nampa</option>
                            <option>Meridian</option>
                            <option>Idaho Falls</option>
                            <option>Pocatello</option>
                          </optgroup>
                          <optgroup label="Illinois">
                            <option>Chicago</option>
                            <option>Aurora</option>
                            <option>Rockford</option>
                            <option>Joliet</option>
                            <option>Naperville</option>
                          </optgroup>
                          <optgroup label="Indiana">
                            <option>Indianapolis</option>
                            <option>Fort Wayne</option>
                            <option>Evansville</option>
                            <option>South Bend</option>
                            <option>Hammond</option>                                   
                          </optgroup>
                          <optgroup label="Iowa">
                            <option>Des Moines</option>
                            <option>Cedar Rapids</option>
                            <option>Davenport</option>
                            <option>Sioux City</option>
                            <option>Waterloo</option>                                 
                          </optgroup>
                          <optgroup label="Kansas">
                            <option>Wichita</option>
                            <option>Overland Park</option>
                            <option>Kansas City</option>
                            <option>Topeka</option>
                            <option>Olathe  </option>                                     
                          </optgroup>
                          <optgroup label="Kentucky">
                            <option>Louisville</option>
                            <option>Lexington</option>
                            <option>Bowling Green</option>
                            <option>Owensboro</option>
                            <option>Covington</option>                                    
                          </optgroup>
                          <optgroup label="Louisiana">
                            <option>New Orleans</option>
                            <option>Baton Rouge</option>
                            <option>Shreveport</option>
                            <option>Metairie</option>
                            <option>Lafayette</option>                                      
                          </optgroup>
                          <optgroup label="Maine">
                            <option>Portland</option>
                            <option>Lewiston</option>
                            <option>Bangor</option>
                            <option>South Portland</option>
                            <option>Auburn</option>                                     
                          </optgroup>
                          <optgroup label="Maryland">
                            <option>Baltimore</option>
                            <option>Frederick</option>
                            <option>Rockville</option>
                            <option>Gaithersburg</option>
                            <option>Bowie</option>                                    
                          </optgroup>
                          <optgroup label="Massachusetts">
                            <option>Boston</option>
                            <option>Worcester</option>
                            <option>Springfield</option>
                            <option>Lowell</option>
                            <option>Cambridge</option>  
                          </optgroup>
                          <optgroup label="Michigan">
                            <option>Detroit</option>
                            <option>Grand Rapids</option>
                            <option>Warren</option>
                            <option>Sterling Heights</option>
                            <option>Lansing</option> 
                          </optgroup>
                          <optgroup label="Minnesota">
                            <option>Minneapolis</option>
                            <option>St. Paul</option>
                            <option>Rochester</option>
                            <option>Duluth</option>
                            <option>Bloomington</option>                                  
                          </optgroup>
                          <optgroup label="Mississippi">
                            <option>Jackson</option>
                            <option>Gulfport</option>
                            <option>Southaven</option>
                            <option>Hattiesburg</option>
                            <option>Biloxi</option>                                     
                          </optgroup>
                          <optgroup label="Missouri">
                            <option>Kansas City</option>
                            <option>St. Louis</option>
                            <option>Springfield</option>
                            <option>Independence</option>
                            <option>Columbia</option>                                       
                          </optgroup>
                          <optgroup label="Montana">
                            <option>Billings</option>
                            <option>Missoula</option>
                            <option>Great Falls</option>
                            <option>Bozeman</option>
                            <option>Butte-Silver Bow</option>                                     
                          </optgroup>
                          <optgroup label="Nebraska">
                            <option>Omaha</option>
                            <option>Lincoln</option>
                            <option>Bellevue</option>
                            <option>Grand Island</option>
                            <option>Kearney</option>                                  
                          </optgroup>
                          <optgroup label="Nevada">
                            <option>Las Vegas</option>
                            <option>Henderson</option>
                            <option>North Las Vegas</option>
                            <option>Reno</option>
                            <option>Sunrise Manor</option>                                      
                          </optgroup>
                          <optgroup label="New Hampshire">
                            <option>Manchesters</option>
                            <option>Nashua</option>
                            <option>Concord</option>
                            <option>Dover</option>
                            <option>Rochester</option>                                        
                          </optgroup>
                          <optgroup label="New Jersey">
                            <option>Newark</option>
                            <option>Jersey City</option>
                            <option>Paterson</option>
                            <option>Elizabeth</option>
                            <option>Edison</option> 
                          </optgroup>
                          <optgroup label="New Mexico">
                            <option>Albuquerque</option>
                            <option>Las Cruces</option>
                            <option>Rio Rancho</option>
                            <option>Santa Fe</option>
                            <option>Roswell</option>       
                          </optgroup>
                          <optgroup label="New York">
                            <option>New York</option>
                            <option>Buffalo</option>
                            <option>Rochester</option>
                            <option>Yonkers</option>
                            <option>Syracuse</option>                                   
                          </optgroup>
                          <optgroup label="North Carolina">
                            <option>Charlotte</option>
                            <option>Raleigh</option>
                            <option>Greensboro</option>
                            <option>Winston-Salem</option>
                            <option>Durham</option>                                     
                          </optgroup>
                          <optgroup label="North Dakota">
                            <option>Fargo</option>
                            <option>Bismarck</option>
                            <option>Grand Forks</option>
                            <option>Minot</option>
                            <option>West Fargo</option>
                          </optgroup>
                          <optgroup label="Ohio">
                            <option>Columbus</option>
                            <option>Cleveland</option>
                            <option>Cincinnati</option>
                            <option>Toledo</option>
                            <option>Akron</option>      
                          </optgroup>
                          <optgroup label="Oklahoma">
                            <option>Oklahoma City</option>
                            <option>Tulsa</option>
                            <option>Norman</option>
                            <option>Broken Arrow</option>
                            <option>Lawton</option>                                   
                          </optgroup>
                          <optgroup label="Oregon">
                            <option>Portland</option>
                            <option>Eugene</option>
                            <option>Salem</option>
                            <option>Gresham</option>
                            <option>Hillsboro</option>                                      
                          </optgroup>
                          <optgroup label="Pennsylvania">
                            <option>Philadelphia</option>
                            <option>Pittsburgh</option>
                            <option>Allentown</option>
                            <option>Erie</option>
                            <option>Reading</option>                                    
                          </optgroup>
                          <optgroup label="Rhode Island">
                            <option>Providence</option>
                            <option>Warwick</option>
                            <option>Cranston</option>
                            <option>Pawtucket</option>
                            <option>East Providence</option>   
                          </optgroup>
                          <optgroup label="South Carolina">
                            <option>Columbia</option>
                            <option>Charleston</option>
                            <option>North Charleston</option>
                            <option>Mount Pleasant</option>
                            <option>Rock Hill</option> 
                          </optgroup>
                          <optgroup label="South Dakota">
                            <option>Sioux Falls</option>
                            <option>Rapid City</option>
                            <option>Aberdeen</option>
                            <option>Brookings</option>
                            <option>Watertown</option> 
                          </optgroup>
                          <optgroup label="Tennessee">
                            <option>Memphis</option>
                            <option>Nashville</option>
                            <option>Knoxville</option>
                            <option>Chattanooga</option>
                            <option>Clarksville</option>       
                          </optgroup>
                          <optgroup label="Texas">
                            <option>Houston</option>
                            <option>San Antonio</option>
                            <option>Dallas</option>
                            <option>Austin</option>
                            <option>Fort Worth</option>   
                          </optgroup>
                          <optgroup label="Utah">
                            <option>Salt Lake City</option>
                            <option>West Valley City</option>
                            <option>Provo</option>
                            <option>West Jordan</option>
                            <option>Orem</option>   
                          </optgroup> 
                          <optgroup label="Vermont">
                            <option>Burlington</option>
                            <option>Essex</option>
                            <option>South Burlington</option>
                            <option>Colchester</option>
                            <option>Rutland</option>   
                          </optgroup>
                          <optgroup label="Virginia">
                            <option>Virginia Beach</option>
                            <option>Norfolk</option>
                            <option>Chesapeake</option>
                            <option>Arlington</option>
                            <option>Richmond</option> 
                          </optgroup> 
                          <optgroup label="Washington">
                            <option>Seattle</option>
                            <option>Spokane</option>
                            <option>Tacoma</option>
                            <option>Vancouver</option>
                            <option>Bellevue</option> 
                          </optgroup> 
                          <optgroup label="West Virginia">
                            <option>Charleston</option>
                            <option>Huntington</option>
                            <option>Parkersburg</option>
                            <option>Morgantown</option>
                            <option>Wheeling</option> 
                          </optgroup> 
                          <optgroup label="Wisconsin">
                            <option>Milwaukee</option>
                            <option>Madison</option>
                            <option>Green Bay</option>
                            <option>Kenosha</option>
                            <option>Racine</option>
                          </optgroup>
                          <optgroup label="Wyoming">
                            <option>Cheyenne</option>
                            <option>Casper</option>
                            <option>Laramie</option>
                            <option>Gillette</option>
                            <option>Rock Springs</option>
                          </optgroup>     
                        </optgroup>
                      </select>
                    </div>
                    </form>    
                </div>
              </div>
            </div>
          </div>
      </div>
    </div>
          </li>
        </ul>
      </div>
      
      <div class="clearfix"> </div> 
    </div>
    <div class="container">
      <div class="agile-its-header">
        <div class="logo">
          <h1><?php
            if(!isset($_SESSION['email_id'])){?>
              <a href="index.html">
     <?php
    } ?>
            <a href="homepage.php"><img src = "bns.png"></a></h1>
        </div>
      </div>
    </div>
  </header>
    <div class="w3layouts-breadcrumbs text-center">
    <div class="container">
      <span class="agile-breadcrumbs"><a href="homepage.php"><i class="fa fa-home home_1"></i></a> / <span>Your Products</span></span>
    </div>
  </div>

<div id = "results">
<div id="product-grid">
  <!-- <div class="ads-grid"> -->
        <div class="ads-display col-md-9" style="border: 0px !important">
          <div class="wrapper">         
          <div class="bs-example bs-example-tabs" role="tabpanel" data-example-id="togglable-tabs">
            
            <div class="tab-content">
            <div role="tabpanel" class="tab-pane fade in active" id="home" aria-labelledby="home-tab">
              <div>
                <div id="container">
                
                <div class="clearfix"></div>
                <ul class="grid" id="grid">
<?php

  if (isset($_GET["page"])) { $page  = $_GET["page"]; } else { $page=1; };  
    $start_from = ($page-1) * $limit; 

    $count = 0;
   	
   	$select_my_items = "SELECT * FROM utility WHERE is_deleted <> '1' AND email_id='".$_SESSION['email_id']."' ORDER BY timestamp DESC LIMIT $start_from, $limit;";
      $items_set_id = mysqli_query($conn, $select_my_items);

      while ($item_id = mysqli_fetch_assoc($items_set_id)) {

        $count = $count + 1;
        # code...
        // echo $item_id['utility_id']."<br>";

        $get_img = "SELECT image_path FROM utility_image where utility_id=".$item_id['utility_id'].";";
        $img_res =  mysqli_query($conn, $get_img);
        $path = mysqli_fetch_assoc($img_res);

        $get_info = "SELECT * FROM utility where utility_id=".$item_id['utility_id'].";";
        $item_info = mysqli_query($conn, $get_info);
        $item_details = mysqli_fetch_assoc($item_info);

        $cat_name = mysqli_query($conn, "SELECT name FROM utility_category where category_id=".$item_details["category_id"]);
        $cat_name_row = mysqli_fetch_assoc($cat_name);

        ?>


        <li>
          <form method="post" action="../php/manage-products.php?action=remove&utility_id=<?php echo $item_details["utility_id"]; ?>">
            <img src="<?php echo $path["image_path"]; ?>" width="200px" height="200px" title="" alt="" />
            <section class="list-left">
              <h5 class="title"><a href="../php/view-product-details.php?page=<?php echo $page; ?>&utility_id=<?php echo $item_id["utility_id"]; ?>"> <?php echo $item_details["name"]; ?> </a></h5>
              <div class="ad-price">
                <?php echo $cat_name_row["name"]; ?></div>
              <div class="ad-price"><?php echo "$".$item_details["price"]; ?></div>
            </section>
            <section class="list-right">
              <div><input type="submit" method="get" formaction="../html/edit_utility_form.php?utility_id=<?php echo $item_details["utility_id"]; ?>" value="Edit" class="btn btn-info" /></div>
              <div><input type="submit" value="Remove" class="btn btn-danger" /></div>
            </section>
            <div class="clearfix"></div>
          </form>
        </li>

        <?php

      }

  if($count == 0)
      {
        echo "<h2 style='text-align: center;'>You haven't listed any product yet!!</h2></div>";
      }
    ?>

                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

</div>

<?php  

  // if($count == 0)
  //     {
  //       echo "<h2 style='text-align: center;'>You haven't listed any product yet!!</h2></div>";
  //     }
  // $sql = "SELECT COUNT(*) FROM utility WHERE is_deleted <> '1' AND email_id='".$_SESSION['email_id']."';";  
  // $rs_result = mysqli_query($conn, $sql);  
  
  // $row = mysqli_fetch_array($rs_result);  
  // // $row = $rs_result;

  // // echo "<pre>";
  // // print_r($row);
  // // echo "</pre>";

  // $total_records = $row[0];  
  // $total_pages = ceil($total_records / $limit);  

  // echo "<div margin-bottom>";
  // $pagLink = "<ul class='pagination pagination-sm'>";
  //     for ($i=1; $i<=$total_pages; $i++) {    
  //            $pagLink .= " "."<li><a href='../html/myproducts.php?page=".$i."'>".$i."</a></li>"; 
  // };  
  // echo $pagLink . "</ul>";  

  echo "</div>"
?>
</div>
  <!--footer section start-->   
  <footer>
      <div class="w3-agileits-footer-top">
        <div class="container">
          <div class="wthree-foo-grids">
            <div class="col-md-3 wthree-footer-grid">
              <h4 class="footer-head">Who We Are</h4>
              <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.</p>
              <p>The point of using Lorem Ipsum is that it has a more-or-less normal letters, as opposed to using 'Content here.</p>
            </div>
            <div class="col-md-3 wthree-footer-grid">
              <h4 class="footer-head">Help</h4>
              <ul>
                <li><a href="howitworks.html"><i class="fa fa-long-arrow-right" aria-hidden="true"></i>How it Works</a></li>            
                <li><a href="sitemap.html"><i class="fa fa-long-arrow-right" aria-hidden="true"></i>Sitemap</a></li>
                <li><a href="faq.html"><i class="fa fa-long-arrow-right" aria-hidden="true"></i>Faq</a></li>
                <li><a href="feedback.html"><i class="fa fa-long-arrow-right" aria-hidden="true"></i>Feedback</a></li>
                <li><a href="contact.html"><i class="fa fa-long-arrow-right" aria-hidden="true"></i>Contact</a></li>
                <li><a href="typography.html"><i class="fa fa-long-arrow-right" aria-hidden="true"></i>Short codes</a></li>
                <li><a href="icons.html"><i class="fa fa-long-arrow-right" aria-hidden="true"></i>Icons Page</a></li>
              </ul>
            </div>
            <div class="col-md-3 wthree-footer-grid">
              <h4 class="footer-head">Information</h4>
              <ul>
                <li><a href="regions.html"><i class="fa fa-long-arrow-right" aria-hidden="true"></i>Locations Map</a></li>  
                <li><a href="terms.html"><i class="fa fa-long-arrow-right" aria-hidden="true"></i>Terms of Use</a></li>
                <li><a href="popular-search.html"><i class="fa fa-long-arrow-right" aria-hidden="true"></i>Popular searches</a></li>  
                <li><a href="privacy.html"><i class="fa fa-long-arrow-right" aria-hidden="true"></i>Privacy Policy</a></li> 
              </ul>
            </div>
            <div class="col-md-3 wthree-footer-grid">
              <h4 class="footer-head">Contact Us</h4>
              <span class="hq">Our headquarters</span>
              <address>
                <ul class="location">
                  <li><span class="glyphicon glyphicon-map-marker"></span></li>
                  <li>CENTER FOR FINANCIAL ASSISTANCE TO DEPOSED NIGERIAN ROYALTY</li>
                </ul> 
                <div class="clearfix"> </div>
                <ul class="location">
                  <li><span class="glyphicon glyphicon-earphone"></span></li>
                  <li>+0 561 111 235</li>
                </ul> 
                <div class="clearfix"> </div>
                <ul class="location">
                  <li><span class="glyphicon glyphicon-envelope"></span></li>
                  <li><a href="mailto:info@example.com">mail@example.com</a></li>
                </ul>           
              </address>
            </div>
            <div class="clearfix"></div>
          </div>            
        </div>  
      </div>  
      <div class="agileits-footer-bottom text-center">
      <div class="container">
        <div class="w3-footer-logo">
          <h1><?php
            if(!isset($_SESSION['email_id'])){?>
              <a href="index.html">
           <?php
    } ?>
            <a href="homepage.php"><img src = "bns.png"></a></h1>
        </div>
        <div class="w3-footer-social-icons">
          <ul>
            <li><a class="facebook" href="#"><i class="fa fa-facebook" aria-hidden="true"></i><span>Facebook</span></a></li>
            <li><a class="twitter" href="#"><i class="fa fa-twitter" aria-hidden="true"></i><span>Twitter</span></a></li>
            <li><a class="flickr" href="#"><i class="fa fa-flickr" aria-hidden="true"></i><span>Flickr</span></a></li>
            <li><a class="googleplus" href="#"><i class="fa fa-google-plus" aria-hidden="true"></i><span>Google+</span></a></li>
            <li><a class="dribbble" href="#"><i class="fa fa-dribbble" aria-hidden="true"></i><span>Dribbble</span></a></li>
          </ul>
        </div>
        <div class="copyrights">
          <p> © 2019 BnS. All Rights Reserved</p>
        </div>
        <div class="clearfix"></div>
      </div>
    </div>
    </footer>
  <!--footer section end-->
</body>
</html>