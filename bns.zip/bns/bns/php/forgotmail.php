<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $mailto = $email;//$_POST['mail_to'];
    $email_id = $mailto;
    $mailSub = "Your Password Reset Link";//$_POST['mail_sub'];
    $mailMsg = "Use this link to reset your password";//$_POST['mail_msg'];

   require '../PHPMailer-master/PHPMailerAutoload.php';
   $mail = new PHPMailer();
   $mail ->IsSmtp();
   $mail ->SMTPDebug = 0;
   $mail ->SMTPAuth = true;
   $mail ->SMTPSecure = 'ssl';
   $mail ->Host = "smtp.gmail.com";
   $mail ->Port = 465; // or 587
   $mail ->IsHTML(true);
   $mail ->Username = "testwpluser@gmail.com";
   $mail ->Password = "Qwerty123#";
   $mail ->SetFrom("testwpluser@gmail.com");
   $mail ->Subject = $mailSub;
   $mail ->Body = $mailMsg;
   $mail ->AddAddress($mailto);

   if(!$mail->Send())
   {
       echo "Mail Not Sent";
   }
   else
   {
       echo "Sending email, please check you inbox";

       // echo "Adding to the cart";
          // $message = "item added to the cart";
          // echo "<script type='text/javascript'>alert('$message');</script>";
          // header("Location: ../html/homepage.php");
          header("refresh:0;../html/signin.html");
          exit();
   }
}




   

