<?php
	
	// Create connection
	$conn = mysqli_connect("localhost", "root", "", "craigslist");
	
	// Check connection
	if (!$conn) {
	    die("Connection failed: " . mysqli_connect_error());
	}

	if(isset($_POST["email"]) and $_POST["email"] != ""){
		$sql = "SELECT * FROM account WHERE email_id='".$_POST["email"]."';";
		$res = mysqli_query($conn, $sql);

		if(mysqli_num_rows($res) > 0)
		{
			echo "<div>Sorry, that email's taken.</div>";
		}
	}
?>