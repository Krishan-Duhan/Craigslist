<?php

    if(!isset($_SESSION)) 
    { 
        session_start(); 
    } 
    if(!isset($_SESSION['email_id'])){
      header("Location: ../html/login.html");
    }

      $limit = 12;

      // Create connection
     $conn = mysqli_connect("localhost", "root", "", "craigslist");
      
      // Check connection
      if (!$conn) {
          die("Connection failed: " . mysqli_connect_error());
      }

if($_SERVER["REQUEST_METHOD"] == "POST"){

	//echo "search and filter results";

	

	$category = $_POST['category'];
	$searchString = $_POST['searchString'];


	if($searchString == ""){
		$searchString = '%';
		$_SESSION['searchString'] = "";
	}
	else{

		$searchString = '%'.$searchString.'%';
		$_SESSION['searchString'] = $searchString;
	}


	// echo "<br>Category: ".$category;
	// echo "<br>Search String: ".$searchString;

	$_SESSION['category'] = $category;
	 $_SESSION['searchString'] = $searchString;

	if (isset($_GET["page"])) { $page  = $_GET["page"]; } else { $page=1; };  
    $start_from = ($page-1) * $limit; 

	if($category == '0'){
		$query = "SELECT * FROM utility WHERE is_deleted <> '1' AND name LIKE '$searchString' ORDER BY timestamp DESC LIMIT $start_from, $limit;";
		$sql = "SELECT COUNT(*) FROM utility WHERE is_deleted <> '1' AND name LIKE '$searchString';";
	}
	else
	{
		// $temp = "%".$searchString."%";
		// echo "<br>".$temp;
		$query = "SELECT * FROM utility WHERE is_deleted <> '1' AND category_id=".$category." AND name LIKE '%%$searchString%%' ORDER BY timestamp DESC LIMIT $start_from, $limit;";	
		$sql = "SELECT COUNT(*) FROM utility WHERE is_deleted <> '1' AND category_id=".$category." AND name LIKE '%%$searchString%%';";
	}

	// echo $query;

	$result = mysqli_query($conn, $query);

	if($result -> num_rows == 0)
	{
		echo "<br>No result found";
	}
	else
	{
		// echo "<br>entire response<br>";

		while($row = mysqli_fetch_assoc($result)){

    		$img_res =  mysqli_query($conn, "SELECT image_path FROM utility_image where utility_id=".$row["utility_id"]);
    		$path = mysqli_fetch_assoc($img_res);

		    // echo "<pre>";
		    // print_r($row);
		    // print_r($path);
		    // echo "</pre>";
?>
		    <li>
                    <form method="post" action="../php/manage-wishlist.php?action=add&page=<?php echo $page; ?>&utility_id=<?php echo $row["utility_id"]; ?>">
                      <img src="<?php echo $path["image_path"]; ?>" width="200px" height="200px" title="" alt="" />
                      <section class="list-left">
                      <h5 class="title"><a href="../php/view-product-details.php?page=<?php echo $page; ?>&utility_id=<?php echo $row["utility_id"]; ?>"> <?php echo $row["name"]; ?> </a></h5>
                      <div class="ad-price">
                        <?php if($row["category_id"] == '1'){
                                  echo "For Sale";
                        }else{
                                  echo "Housing";
                        } ?></div>
                      <div class="ad-price"><?php echo "$".$row["price"]; ?></div>
                      </section>
                      <section class="list-right">
                      <div><input type="submit" value="Add to wishlist" class="btn btn-success" /></div>
                      </section>
                      <div class="clearfix"></div>
                    </form>
                  </li> 
<?php 	} 
	}
}

?>

<?php  
  // $sql = "SELECT COUNT(*) FROM utility WHERE is_deleted <> '1';";  
// echo $sql;
  $rs_result = mysqli_query($conn, $sql);  
  
  $row = mysqli_fetch_array($rs_result);  
  // $row = $rs_result;

  // echo "<pre>";
  // print_r($row);
  // echo "</pre>";

  $total_records = $row[0];  
  // echo $total_records;
  $total_pages = ceil($total_records / $limit);  

  echo "<div margin-bottom>";
  $pagLink = "<div class='pagination' style ='margin-bottom:20px; margin-left:100px'>";  
  for ($i=1; $i<=$total_pages; $i++) {  
             $pagLink .= " "."<a class='page-link' href='../html/homepage.php?page=".$i."'>".$i."</a>";  
  };  
  echo $pagLink . "</div>";  

  echo "</div>"
?>

</div>