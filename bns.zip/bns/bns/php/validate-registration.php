<?php

// Create connection
$conn = mysqli_connect("localhost", "root", "", "craigslist");
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $pwd = sha1($_POST['password']);
	$fname = $_POST['firstname'];
	$lname = $_POST['lastname'];
	$email = $_POST['email'];
	$phone = $_POST['phone'];
	$addr = $_POST['address1'];
	$city = $_POST['city'];
	$state = $_POST['state'];
	$zip = $_POST['zipcode'];
	$country = $_POST['country'];

	$create_account = "INSERT INTO account(email_id, password)
	VALUES ('$email', '$pwd');";

	$create_user = "INSERT INTO user (email_id, firstname, lastname, phone_no, street, city, state, zipcode, country, rating, isAdmin)
	VALUES 						('$email', '$fname', '$lname', '$phone', '$addr', '$city', '$state', '$zip', '$country', 0, 0);";

	if (mysqli_query($conn, $create_user) and mysqli_query($conn, $create_account)) {
	    header("refresh:0;../html/login.html");
		echo "<script type='text/javascript'>alert('Successfully Registered!');</script>";
	} else {
	    
	    header("refresh:0;../html/register.html");
		echo "<script type='text/javascript'>alert('Sorry, email has been taken!');</script>";
	}
}
mysqli_close($conn);
?>