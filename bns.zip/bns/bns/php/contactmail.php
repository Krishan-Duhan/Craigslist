<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $message = $_POST['name'];
    $mailto = "testwpluser@gmail.com";
    $email_id = $mailto;
    $mailSub = "Contact us mail from ".$_POST['email'];//$_POST['mail_sub'];
    $mailMsg = $_POST['msg'];
    $mailMsg .= "<br><br>";
    $mailMsg .= "Id: ".$_POST["id"];
    $mailMsg .= "<br><br>";
    $mailMsg .= "Phone: ".$_POST["tel"];
    $mailMsg .= "<br><br>";

   require '../PHPMailer-master/PHPMailerAutoload.php';
   $mail = new PHPMailer();
   $mail ->IsSmtp();
   $mail ->SMTPDebug = 0;
   $mail ->SMTPAuth = true;
   $mail ->SMTPSecure = 'ssl';
   $mail ->Host = "smtp.gmail.com";
   $mail ->Port = 465; // or 587
   $mail ->IsHTML(true);
   $mail ->Username = "testwpluser@gmail.com";
   $mail ->Password = "Qwerty123#";
   $mail ->SetFrom("testwpluser@gmail.com");
   $mail ->Subject = $mailSub;
   $mail ->Body = $mailMsg;
   $mail ->AddAddress($mailto);

   if(!$mail->Send())
   {
       echo "Mail Not Sent";
   }
   else
   {
       echo "Sending email, please check you inbox";

       // echo "Adding to the cart";
          $message = "We received your Message.";
        echo "<script type='text/javascript'>alert('$message');</script>";
          // header("Location: ../html/homepage.php");
          header("refresh:0;../html/index.html");
          exit();
   }
}




   

