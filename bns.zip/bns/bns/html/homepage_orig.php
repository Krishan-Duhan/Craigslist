<?php
    if(!isset($_SESSION)) 
    { 
        session_start(); 
    } 
    if(isset($_SESSION['searchString'])) 
    { 
        $_SESSION['searchString']='%';
    }
    if(!isset($_SESSION['email_id'])){
      header("Location: login.html");
    }

      $limit = 12;

      // Create connection
      $conn = mysqli_connect("localhost", "root", "", "craigslist");
      
      // Check connection
      if (!$conn) {
          die("Connection failed: " . mysqli_connect_error());
      }
?>
<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html lang="en">
<head>
<title>Buy N Sell: BnS</title>
<link rel="stylesheet" href="../css/bootstrap.min.css"><!-- bootstrap-CSS -->
<link rel="stylesheet" href="../css/bootstrap-select.css"><!-- bootstrap-select-CSS -->
<link href="../css/style.css" rel="stylesheet" type="text/css" media="all" /><!-- style.css -->
<link rel="stylesheet" href="../css/flexslider.css" type="text/css" media="screen" /><!-- flexslider-CSS -->
<link rel="stylesheet" href="../css/font-awesome.min.css" /><!-- fontawesome-CSS -->
<link rel="stylesheet" href="../css/menu_sideslide.css" type="text/css" media="all"><!-- Navigation-CSS -->
<!-- meta tags -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Resale Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //meta tags -->
<!--fonts-->
<link href='//fonts.googleapis.com/css?family=Ubuntu+Condensed' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<!--//fonts--> 
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
    <!--Import Google Icon Font-->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/bootstrap-select.js"></script>
    <script type="text/javascript">
        function filter_result() {
        // body...
        var q = "category="+$('li.selected').data('original-index')+"&searchString="+$("#searchString").val();
        //console.log("Hi : "+q);
        $.ajax({
          type: "POST",
          url: "../php/searchandfilter.php",
          //data: jQuery("#filter-form1").serialize(),
          data: q,
          success: function(data){
            console.log(data);

            document.getElementById("grid").innerHTML = data;
          }
        });
      }
    </script> 
</head>
<body>  
    <!-- Navigation -->
    <div class="agiletopbar">
      <div class="wthreenavigation">
        <div class="menu-wrap">
        <nav class="menu">
          <div class="icon-list">
            <a href="../html/homepage.php"><i class="fa fa-fw fa-mobile"></i><span>Products</span></a>
            <a href="../php/mywishlist.php"><i class="fa fa-fw fa-laptop"></i><span>Wishlist</span></a>
            <a href="../html/utility.php"><i class="fa fa-fw fa-car"></i><span>Add Product</span></a>
            <a href="../html/myproducts.php"><i class="fa fa-fw fa-motorcycle"></i><span>My Products</span></a>
                <?php
            if(isset($_SESSION['isAdmin']) && $_SESSION['isAdmin']==1){
          ?>
            <a href="../php/view_users.php"><i class="fa fa-fw fa-wheelchair"></i><span>View Users</span></a>  <?php
          }
          ?>
          </div>
        </nav>
        <button class="close-button" id="close-button">Close Menu</button>
      </div>
      <button class="menu-button" id="open-button"> </button>
      </div>
      <div class="clearfix"></div>
    </div>
    <!-- //Navigation -->
  <!-- header -->
<!--   <header>
      <div class="w3ls-header-left">
        <p><a href="../mobileapp.html"><i class="fa fa-download" aria-hidden="true"></i>Download Mobile App </a></p>
      </div>
      <div class="w3ls-header-right">
        <ul>
          <li class="dropdown head-dpdn">
            <a href="../signin.html" aria-expanded="false"><i class="fa fa-user" aria-hidden="true"></i> Sign In</a>
          </li>
          <li class="dropdown head-dpdn">
            <a href="../help.html"><i class="fa fa-question-circle" aria-hidden="true"></i> Help</a>
          </li>
          
          <li class="dropdown head-dpdn">
            <div class="header-right">      
  
      <div class="agile-its-selectregion">
        <button class="btn btn-primary" data-toggle="modal" data-target="#myModal">
        <i class="fa fa-globe" aria-hidden="true"></i>Select City</button>
          <div class="modal fade" id="myModal" tabindex="-1" role="dialog"
          aria-hidden="true">
            <div class="modal-dialog modal-lg">
              <div class="modal-content">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                    &times;</button>
                  <h4 class="modal-title" id="myModalLabel">
                    Please Choose Your Location</h4>
                </div>
                <div class="modal-body">
                   <form class="form-horizontal" action="#" method="get">
                    <div class="form-group">
                      <select id="basic2" class="show-tick form-control" multiple>
                        <optgroup label="Popular Cities">
                          <option selected style="display:none;color:#eee;">Select City</option>
                          <option>Birmingham</option>
                          <option>Anchorage</option>
                          <option>Phoenix</option>
                          <option>Little Rock</option>
                          <option>Los Angeles</option>
                          <option>Denver</option>
                          <option>Bridgeport</option>
                          <option>Wilmington</option>
                          <option>Jacksonville</option>
                          <option>Atlanta</option>
                          <option>Honolulu</option>
                          <option>Boise</option>
                          <option>Chicago</option>
                          <option>Indianapolis</option>
                        </optgroup>
                          <optgroup label="Alabama">
                            <option>Birmingham</option>
                            <option>Montgomery</option>
                            <option>Mobile</option>
                            <option>Huntsville</option>
                            <option>Tuscaloosa</option>
                          </optgroup>
                          <optgroup label="Alaska">
                            <option>Anchorage</option>
                            <option>Fairbanks</option>
                            <option>Juneau</option>
                            <option>Sitka</option>
                            <option>Ketchikan</option>
                          </optgroup>
                          <optgroup label="Arizona">
                            <option>Phoenix</option>
                            <option>Tucson</option>
                            <option>Mesa</option>
                            <option>Chandler</option>
                            <option>Glendale</option>
                          </optgroup>
                          <optgroup label="Arkansas">
                            <option>Little Rock</option>
                            <option>Fort Smith</option>
                            <option>Fayetteville</option>
                            <option>Springdale</option>
                            <option>Jonesboro</option>
                          </optgroup>
                          <optgroup label="California">
                            <option>Los Angeles</option>
                            <option>San Diego</option>
                            <option>San Jose</option>
                            <option>San Francisco</option>
                            <option>Fresno</option>
                          </optgroup>
                          <optgroup label="Colorado">
                            <option>Denver</option>
                            <option>Colorado</option>
                            <option>Aurora</option>
                            <option>Fort Collins</option>
                            <option>Lakewood</option>
                          </optgroup>
                          <optgroup label="Connecticut">
                            <option>Bridgeport</option>
                            <option>New Haven</option>
                            <option>Hartford</option>
                            <option>Stamford</option>
                            <option>Waterbury</option>
                          </optgroup>
                          <optgroup label="Delaware">
                            <option>Wilmington</option>
                            <option>Dover</option>
                            <option>Newark</option>
                            <option>Bear</option>
                            <option>Middletown</option>
                          </optgroup>
                          <optgroup label="Florida">
                            <option>Jacksonville</option>
                            <option>Miami</option>
                            <option>Tampa</option>
                            <option>St. Petersburg</option>
                            <option>Orlando</option>
                          </optgroup>
                          <optgroup label="Georgia">
                            <option>Atlanta</option>
                            <option>Augusta</option>
                            <option>Columbus</option>
                            <option>Savannah</option>
                            <option>Athens</option>
                          </optgroup>
                          <optgroup label="Hawaii">
                            <option>Honolulu</option>
                            <option>Pearl City</option>
                            <option>Hilo</option>
                            <option>Kailua</option>
                            <option>Waipahu</option>
                          </optgroup>
                          <optgroup label="Idaho">
                            <option>Boise</option>
                            <option>Nampa</option>
                            <option>Meridian</option>
                            <option>Idaho Falls</option>
                            <option>Pocatello</option>
                          </optgroup>
                          <optgroup label="Illinois">
                            <option>Chicago</option>
                            <option>Aurora</option>
                            <option>Rockford</option>
                            <option>Joliet</option>
                            <option>Naperville</option>
                          </optgroup>
                          <optgroup label="Indiana">
                            <option>Indianapolis</option>
                            <option>Fort Wayne</option>
                            <option>Evansville</option>
                            <option>South Bend</option>
                            <option>Hammond</option>                                   
                          </optgroup>
                          <optgroup label="Iowa">
                            <option>Des Moines</option>
                            <option>Cedar Rapids</option>
                            <option>Davenport</option>
                            <option>Sioux City</option>
                            <option>Waterloo</option>                                 
                          </optgroup>
                          <optgroup label="Kansas">
                            <option>Wichita</option>
                            <option>Overland Park</option>
                            <option>Kansas City</option>
                            <option>Topeka</option>
                            <option>Olathe  </option>                                     
                          </optgroup>
                          <optgroup label="Kentucky">
                            <option>Louisville</option>
                            <option>Lexington</option>
                            <option>Bowling Green</option>
                            <option>Owensboro</option>
                            <option>Covington</option>                                    
                          </optgroup>
                          <optgroup label="Louisiana">
                            <option>New Orleans</option>
                            <option>Baton Rouge</option>
                            <option>Shreveport</option>
                            <option>Metairie</option>
                            <option>Lafayette</option>                                      
                          </optgroup>
                          <optgroup label="Maine">
                            <option>Portland</option>
                            <option>Lewiston</option>
                            <option>Bangor</option>
                            <option>South Portland</option>
                            <option>Auburn</option>                                     
                          </optgroup>
                          <optgroup label="Maryland">
                            <option>Baltimore</option>
                            <option>Frederick</option>
                            <option>Rockville</option>
                            <option>Gaithersburg</option>
                            <option>Bowie</option>                                    
                          </optgroup>
                          <optgroup label="Massachusetts">
                            <option>Boston</option>
                            <option>Worcester</option>
                            <option>Springfield</option>
                            <option>Lowell</option>
                            <option>Cambridge</option>  
                          </optgroup>
                          <optgroup label="Michigan">
                            <option>Detroit</option>
                            <option>Grand Rapids</option>
                            <option>Warren</option>
                            <option>Sterling Heights</option>
                            <option>Lansing</option> 
                          </optgroup>
                          <optgroup label="Minnesota">
                            <option>Minneapolis</option>
                            <option>St. Paul</option>
                            <option>Rochester</option>
                            <option>Duluth</option>
                            <option>Bloomington</option>                                  
                          </optgroup>
                          <optgroup label="Mississippi">
                            <option>Jackson</option>
                            <option>Gulfport</option>
                            <option>Southaven</option>
                            <option>Hattiesburg</option>
                            <option>Biloxi</option>                                     
                          </optgroup>
                          <optgroup label="Missouri">
                            <option>Kansas City</option>
                            <option>St. Louis</option>
                            <option>Springfield</option>
                            <option>Independence</option>
                            <option>Columbia</option>                                       
                          </optgroup>
                          <optgroup label="Montana">
                            <option>Billings</option>
                            <option>Missoula</option>
                            <option>Great Falls</option>
                            <option>Bozeman</option>
                            <option>Butte-Silver Bow</option>                                     
                          </optgroup>
                          <optgroup label="Nebraska">
                            <option>Omaha</option>
                            <option>Lincoln</option>
                            <option>Bellevue</option>
                            <option>Grand Island</option>
                            <option>Kearney</option>                                  
                          </optgroup>
                          <optgroup label="Nevada">
                            <option>Las Vegas</option>
                            <option>Henderson</option>
                            <option>North Las Vegas</option>
                            <option>Reno</option>
                            <option>Sunrise Manor</option>                                      
                          </optgroup>
                          <optgroup label="New Hampshire">
                            <option>Manchesters</option>
                            <option>Nashua</option>
                            <option>Concord</option>
                            <option>Dover</option>
                            <option>Rochester</option>                                        
                          </optgroup>
                          <optgroup label="New Jersey">
                            <option>Newark</option>
                            <option>Jersey City</option>
                            <option>Paterson</option>
                            <option>Elizabeth</option>
                            <option>Edison</option> 
                          </optgroup>
                          <optgroup label="New Mexico">
                            <option>Albuquerque</option>
                            <option>Las Cruces</option>
                            <option>Rio Rancho</option>
                            <option>Santa Fe</option>
                            <option>Roswell</option>       
                          </optgroup>
                          <optgroup label="New York">
                            <option>New York</option>
                            <option>Buffalo</option>
                            <option>Rochester</option>
                            <option>Yonkers</option>
                            <option>Syracuse</option>                                   
                          </optgroup>
                          <optgroup label="North Carolina">
                            <option>Charlotte</option>
                            <option>Raleigh</option>
                            <option>Greensboro</option>
                            <option>Winston-Salem</option>
                            <option>Durham</option>                                     
                          </optgroup>
                          <optgroup label="North Dakota">
                            <option>Fargo</option>
                            <option>Bismarck</option>
                            <option>Grand Forks</option>
                            <option>Minot</option>
                            <option>West Fargo</option>
                          </optgroup>
                          <optgroup label="Ohio">
                            <option>Columbus</option>
                            <option>Cleveland</option>
                            <option>Cincinnati</option>
                            <option>Toledo</option>
                            <option>Akron</option>      
                          </optgroup>
                          <optgroup label="Oklahoma">
                            <option>Oklahoma City</option>
                            <option>Tulsa</option>
                            <option>Norman</option>
                            <option>Broken Arrow</option>
                            <option>Lawton</option>                                   
                          </optgroup>
                          <optgroup label="Oregon">
                            <option>Portland</option>
                            <option>Eugene</option>
                            <option>Salem</option>
                            <option>Gresham</option>
                            <option>Hillsboro</option>                                      
                          </optgroup>
                          <optgroup label="Pennsylvania">
                            <option>Philadelphia</option>
                            <option>Pittsburgh</option>
                            <option>Allentown</option>
                            <option>Erie</option>
                            <option>Reading</option>                                    
                          </optgroup>
                          <optgroup label="Rhode Island">
                            <option>Providence</option>
                            <option>Warwick</option>
                            <option>Cranston</option>
                            <option>Pawtucket</option>
                            <option>East Providence</option>   
                          </optgroup>
                          <optgroup label="South Carolina">
                            <option>Columbia</option>
                            <option>Charleston</option>
                            <option>North Charleston</option>
                            <option>Mount Pleasant</option>
                            <option>Rock Hill</option> 
                          </optgroup>
                          <optgroup label="South Dakota">
                            <option>Sioux Falls</option>
                            <option>Rapid City</option>
                            <option>Aberdeen</option>
                            <option>Brookings</option>
                            <option>Watertown</option> 
                          </optgroup>
                          <optgroup label="Tennessee">
                            <option>Memphis</option>
                            <option>Nashville</option>
                            <option>Knoxville</option>
                            <option>Chattanooga</option>
                            <option>Clarksville</option>       
                          </optgroup>
                          <optgroup label="Texas">
                            <option>Houston</option>
                            <option>San Antonio</option>
                            <option>Dallas</option>
                            <option>Austin</option>
                            <option>Fort Worth</option>   
                          </optgroup>
                          <optgroup label="Utah">
                            <option>Salt Lake City</option>
                            <option>West Valley City</option>
                            <option>Provo</option>
                            <option>West Jordan</option>
                            <option>Orem</option>   
                          </optgroup> 
                          <optgroup label="Vermont">
                            <option>Burlington</option>
                            <option>Essex</option>
                            <option>South Burlington</option>
                            <option>Colchester</option>
                            <option>Rutland</option>   
                          </optgroup>
                          <optgroup label="Virginia">
                            <option>Virginia Beach</option>
                            <option>Norfolk</option>
                            <option>Chesapeake</option>
                            <option>Arlington</option>
                            <option>Richmond</option> 
                          </optgroup> 
                          <optgroup label="Washington">
                            <option>Seattle</option>
                            <option>Spokane</option>
                            <option>Tacoma</option>
                            <option>Vancouver</option>
                            <option>Bellevue</option> 
                          </optgroup> 
                          <optgroup label="West Virginia">
                            <option>Charleston</option>
                            <option>Huntington</option>
                            <option>Parkersburg</option>
                            <option>Morgantown</option>
                            <option>Wheeling</option> 
                          </optgroup> 
                          <optgroup label="Wisconsin">
                            <option>Milwaukee</option>
                            <option>Madison</option>
                            <option>Green Bay</option>
                            <option>Kenosha</option>
                            <option>Racine</option>
                          </optgroup>
                          <optgroup label="Wyoming">
                            <option>Cheyenne</option>
                            <option>Casper</option>
                            <option>Laramie</option>
                            <option>Gillette</option>
                            <option>Rock Springs</option>
                          </optgroup>
                      </select>
                    </div>
                    </form>    
                </div>
              </div>
            </div>
          </div>
      </div>
    </div>
          </li>
        </ul>
      </div>
      
      <div class="clearfix"> </div> 
    </div>
    <div class="container">
      <div class="agile-its-header">
        <div class="logo">
          <h1><a href="#"><img src="../images/BNSLogo.png" alt=""></a></h1>
        </div>
        <div class="agileits_search">
          <form action="#" method="post">
            <input name="Search" type="text" placeholder="Search For a Specific Product" required="" />
            
        
            <select id="agileinfo_search" name="agileinfo_search" required="">
              <option value="all">All Categories</option>
              <option value="For Sale">Sale</option>
              <option value="Housing">Housing</option>
            </select>
                       
            <button type="submit" class="btn btn-default" aria-label="Right Align">
              <i class="fa fa-search" aria-hidden="true"> </i>
            </button>
          </form>
       
        </div>  
        <div class="clearfix"></div>
      </div>
    </div>
  </header> -->
    <header>
    <div class="w3ls-header"><!--header-one--> 
      <div class="w3ls-header-right">
        <ul>
          <li class="dropdown head-dpdn">
            <a href="../php/destroysession.php" aria-expanded="false"><i class="fa fa-user" aria-hidden="true"></i> Logout</a>

          <?php
            if(isset($_SESSION['isAdmin']) && $_SESSION['isAdmin']==1){
          ?>
          <script type="text/javascript"> $("a.fa fa-user").css("width","12%");</script>
          <?php
          }?>
          </li>
          <li class="dropdown head-dpdn">
            <a href="help.html"><i class="fa fa-question-circle" aria-hidden="true"></i> Help</a>
          </li>
          <li class="dropdown head-dpdn">
            <a href="#"><span class="active uls-trigger"><i class="fa fa-language" aria-hidden="true"></i>languages</span></a>
          </li>
          <li class="dropdown head-dpdn">
            <div class="header-right">      
  <!-- Large modal -->
      <div class="selectregion">
        <button class="btn btn-primary" data-toggle="modal" data-target="#myModal">
        <i class="fa fa-globe" aria-hidden="true"></i>Select City</button>
          <div class="modal fade" id="myModal" tabindex="-1" role="dialog"  
          aria-hidden="true">
            <div class="modal-dialog modal-lg">
              <div class="modal-content">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                    &times;</button>
                  <h4 class="modal-title" id="myModalLabel">
                    Please Choose Your Location</h4>
                </div>
                <div class="modal-body">
                   <form class="form-horizontal" action="#" method="get">
                    <div class="form-group">
                      <select id="basic2" class="show-tick form-control" multiple>
                        <optgroup label="Popular Cities">
                          <option selected style="display:none;color:#eee;">Select City</option>
                          <option>Birmingham</option>
                          <option>Anchorage</option>
                          <option>Phoenix</option>
                          <option>Little Rock</option>
                          <option>Los Angeles</option>
                          <option>Denver</option>
                          <option>Bridgeport</option>
                          <option>Wilmington</option>
                          <option>Jacksonville</option>
                          <option>Atlanta</option>
                          <option>Honolulu</option>
                          <option>Boise</option>
                          <option>Chicago</option>
                          <option>Indianapolis</option>
                        </optgroup>
                        <optgroup label="More Cities">
                          <optgroup label="Alabama">
                            <option>Birmingham</option>
                            <option>Montgomery</option>
                            <option>Mobile</option>
                            <option>Huntsville</option>
                            <option>Tuscaloosa</option>
                          </optgroup>
                          <optgroup label="Alaska">
                            <option>Anchorage</option>
                            <option>Fairbanks</option>
                            <option>Juneau</option>
                            <option>Sitka</option>
                            <option>Ketchikan</option>
                          </optgroup>
                          <optgroup label="Arizona">
                            <option>Phoenix</option>
                            <option>Tucson</option>
                            <option>Mesa</option>
                            <option>Chandler</option>
                            <option>Glendale</option>
                          </optgroup>
                          <optgroup label="Arkansas">
                            <option>Little Rock</option>
                            <option>Fort Smith</option>
                            <option>Fayetteville</option>
                            <option>Springdale</option>
                            <option>Jonesboro</option>
                          </optgroup>
                          <optgroup label="California">
                            <option>Los Angeles</option>
                            <option>San Diego</option>
                            <option>San Jose</option>
                            <option>San Francisco</option>
                            <option>Fresno</option>
                          </optgroup>
                          <optgroup label="Colorado">
                            <option>Denver</option>
                            <option>Colorado</option>
                            <option>Aurora</option>
                            <option>Fort Collins</option>
                            <option>Lakewood</option>
                          </optgroup>
                          <optgroup label="Connecticut">
                            <option>Bridgeport</option>
                            <option>New Haven</option>
                            <option>Hartford</option>
                            <option>Stamford</option>
                            <option>Waterbury</option>
                          </optgroup>
                          <optgroup label="Delaware">
                            <option>Wilmington</option>
                            <option>Dover</option>
                            <option>Newark</option>
                            <option>Bear</option>
                            <option>Middletown</option>
                          </optgroup>
                          <optgroup label="Florida">
                            <option>Jacksonville</option>
                            <option>Miami</option>
                            <option>Tampa</option>
                            <option>St. Petersburg</option>
                            <option>Orlando</option>
                          </optgroup>
                          <optgroup label="Georgia">
                            <option>Atlanta</option>
                            <option>Augusta</option>
                            <option>Columbus</option>
                            <option>Savannah</option>
                            <option>Athens</option>
                          </optgroup>
                          <optgroup label="Hawaii">
                            <option>Honolulu</option>
                            <option>Pearl City</option>
                            <option>Hilo</option>
                            <option>Kailua</option>
                            <option>Waipahu</option>
                          </optgroup>
                          <optgroup label="Idaho">
                            <option>Boise</option>
                            <option>Nampa</option>
                            <option>Meridian</option>
                            <option>Idaho Falls</option>
                            <option>Pocatello</option>
                          </optgroup>
                          <optgroup label="Illinois">
                            <option>Chicago</option>
                            <option>Aurora</option>
                            <option>Rockford</option>
                            <option>Joliet</option>
                            <option>Naperville</option>
                          </optgroup>
                          <optgroup label="Indiana">
                            <option>Indianapolis</option>
                            <option>Fort Wayne</option>
                            <option>Evansville</option>
                            <option>South Bend</option>
                            <option>Hammond</option>                                   
                          </optgroup>
                          <optgroup label="Iowa">
                            <option>Des Moines</option>
                            <option>Cedar Rapids</option>
                            <option>Davenport</option>
                            <option>Sioux City</option>
                            <option>Waterloo</option>                                 
                          </optgroup>
                          <optgroup label="Kansas">
                            <option>Wichita</option>
                            <option>Overland Park</option>
                            <option>Kansas City</option>
                            <option>Topeka</option>
                            <option>Olathe  </option>                                     
                          </optgroup>
                          <optgroup label="Kentucky">
                            <option>Louisville</option>
                            <option>Lexington</option>
                            <option>Bowling Green</option>
                            <option>Owensboro</option>
                            <option>Covington</option>                                    
                          </optgroup>
                          <optgroup label="Louisiana">
                            <option>New Orleans</option>
                            <option>Baton Rouge</option>
                            <option>Shreveport</option>
                            <option>Metairie</option>
                            <option>Lafayette</option>                                      
                          </optgroup>
                          <optgroup label="Maine">
                            <option>Portland</option>
                            <option>Lewiston</option>
                            <option>Bangor</option>
                            <option>South Portland</option>
                            <option>Auburn</option>                                     
                          </optgroup>
                          <optgroup label="Maryland">
                            <option>Baltimore</option>
                            <option>Frederick</option>
                            <option>Rockville</option>
                            <option>Gaithersburg</option>
                            <option>Bowie</option>                                    
                          </optgroup>
                          <optgroup label="Massachusetts">
                            <option>Boston</option>
                            <option>Worcester</option>
                            <option>Springfield</option>
                            <option>Lowell</option>
                            <option>Cambridge</option>  
                          </optgroup>
                          <optgroup label="Michigan">
                            <option>Detroit</option>
                            <option>Grand Rapids</option>
                            <option>Warren</option>
                            <option>Sterling Heights</option>
                            <option>Lansing</option> 
                          </optgroup>
                          <optgroup label="Minnesota">
                            <option>Minneapolis</option>
                            <option>St. Paul</option>
                            <option>Rochester</option>
                            <option>Duluth</option>
                            <option>Bloomington</option>                                  
                          </optgroup>
                          <optgroup label="Mississippi">
                            <option>Jackson</option>
                            <option>Gulfport</option>
                            <option>Southaven</option>
                            <option>Hattiesburg</option>
                            <option>Biloxi</option>                                     
                          </optgroup>
                          <optgroup label="Missouri">
                            <option>Kansas City</option>
                            <option>St. Louis</option>
                            <option>Springfield</option>
                            <option>Independence</option>
                            <option>Columbia</option>                                       
                          </optgroup>
                          <optgroup label="Montana">
                            <option>Billings</option>
                            <option>Missoula</option>
                            <option>Great Falls</option>
                            <option>Bozeman</option>
                            <option>Butte-Silver Bow</option>                                     
                          </optgroup>
                          <optgroup label="Nebraska">
                            <option>Omaha</option>
                            <option>Lincoln</option>
                            <option>Bellevue</option>
                            <option>Grand Island</option>
                            <option>Kearney</option>                                  
                          </optgroup>
                          <optgroup label="Nevada">
                            <option>Las Vegas</option>
                            <option>Henderson</option>
                            <option>North Las Vegas</option>
                            <option>Reno</option>
                            <option>Sunrise Manor</option>                                      
                          </optgroup>
                          <optgroup label="New Hampshire">
                            <option>Manchesters</option>
                            <option>Nashua</option>
                            <option>Concord</option>
                            <option>Dover</option>
                            <option>Rochester</option>                                        
                          </optgroup>
                          <optgroup label="New Jersey">
                            <option>Newark</option>
                            <option>Jersey City</option>
                            <option>Paterson</option>
                            <option>Elizabeth</option>
                            <option>Edison</option> 
                          </optgroup>
                          <optgroup label="New Mexico">
                            <option>Albuquerque</option>
                            <option>Las Cruces</option>
                            <option>Rio Rancho</option>
                            <option>Santa Fe</option>
                            <option>Roswell</option>       
                          </optgroup>
                          <optgroup label="New York">
                            <option>New York</option>
                            <option>Buffalo</option>
                            <option>Rochester</option>
                            <option>Yonkers</option>
                            <option>Syracuse</option>                                   
                          </optgroup>
                          <optgroup label="North Carolina">
                            <option>Charlotte</option>
                            <option>Raleigh</option>
                            <option>Greensboro</option>
                            <option>Winston-Salem</option>
                            <option>Durham</option>                                     
                          </optgroup>
                          <optgroup label="North Dakota">
                            <option>Fargo</option>
                            <option>Bismarck</option>
                            <option>Grand Forks</option>
                            <option>Minot</option>
                            <option>West Fargo</option>
                          </optgroup>
                          <optgroup label="Ohio">
                            <option>Columbus</option>
                            <option>Cleveland</option>
                            <option>Cincinnati</option>
                            <option>Toledo</option>
                            <option>Akron</option>      
                          </optgroup>
                          <optgroup label="Oklahoma">
                            <option>Oklahoma City</option>
                            <option>Tulsa</option>
                            <option>Norman</option>
                            <option>Broken Arrow</option>
                            <option>Lawton</option>                                   
                          </optgroup>
                          <optgroup label="Oregon">
                            <option>Portland</option>
                            <option>Eugene</option>
                            <option>Salem</option>
                            <option>Gresham</option>
                            <option>Hillsboro</option>                                      
                          </optgroup>
                          <optgroup label="Pennsylvania">
                            <option>Philadelphia</option>
                            <option>Pittsburgh</option>
                            <option>Allentown</option>
                            <option>Erie</option>
                            <option>Reading</option>                                    
                          </optgroup>
                          <optgroup label="Rhode Island">
                            <option>Providence</option>
                            <option>Warwick</option>
                            <option>Cranston</option>
                            <option>Pawtucket</option>
                            <option>East Providence</option>   
                          </optgroup>
                          <optgroup label="South Carolina">
                            <option>Columbia</option>
                            <option>Charleston</option>
                            <option>North Charleston</option>
                            <option>Mount Pleasant</option>
                            <option>Rock Hill</option> 
                          </optgroup>
                          <optgroup label="South Dakota">
                            <option>Sioux Falls</option>
                            <option>Rapid City</option>
                            <option>Aberdeen</option>
                            <option>Brookings</option>
                            <option>Watertown</option> 
                          </optgroup>
                          <optgroup label="Tennessee">
                            <option>Memphis</option>
                            <option>Nashville</option>
                            <option>Knoxville</option>
                            <option>Chattanooga</option>
                            <option>Clarksville</option>       
                          </optgroup>
                          <optgroup label="Texas">
                            <option>Houston</option>
                            <option>San Antonio</option>
                            <option>Dallas</option>
                            <option>Austin</option>
                            <option>Fort Worth</option>   
                          </optgroup>
                          <optgroup label="Utah">
                            <option>Salt Lake City</option>
                            <option>West Valley City</option>
                            <option>Provo</option>
                            <option>West Jordan</option>
                            <option>Orem</option>   
                          </optgroup> 
                          <optgroup label="Vermont">
                            <option>Burlington</option>
                            <option>Essex</option>
                            <option>South Burlington</option>
                            <option>Colchester</option>
                            <option>Rutland</option>   
                          </optgroup>
                          <optgroup label="Virginia">
                            <option>Virginia Beach</option>
                            <option>Norfolk</option>
                            <option>Chesapeake</option>
                            <option>Arlington</option>
                            <option>Richmond</option> 
                          </optgroup> 
                          <optgroup label="Washington">
                            <option>Seattle</option>
                            <option>Spokane</option>
                            <option>Tacoma</option>
                            <option>Vancouver</option>
                            <option>Bellevue</option> 
                          </optgroup> 
                          <optgroup label="West Virginia">
                            <option>Charleston</option>
                            <option>Huntington</option>
                            <option>Parkersburg</option>
                            <option>Morgantown</option>
                            <option>Wheeling</option> 
                          </optgroup> 
                          <optgroup label="Wisconsin">
                            <option>Milwaukee</option>
                            <option>Madison</option>
                            <option>Green Bay</option>
                            <option>Kenosha</option>
                            <option>Racine</option>
                          </optgroup>
                          <optgroup label="Wyoming">
                            <option>Cheyenne</option>
                            <option>Casper</option>
                            <option>Laramie</option>
                            <option>Gillette</option>
                            <option>Rock Springs</option>
                          </optgroup>     
                        </optgroup>
                      </select>
                    </div>
                    </form>    
                </div>
              </div>
            </div>
          </div>
      </div>
    </div>
          </li>
        </ul>
      </div>
      
      <div class="clearfix"> </div> 
    </div>
    <div class="container">
      <div class="agile-its-header">
        <div class="logo">
          <h1><?php
            if(!isset($_SESSION['email_id'])){?>
              <a href="index.html">
     <?php
    } ?>
            <a href="homepage.php"><img src = "bns.png"></a></h1>
        </div>
          <div class="agileits_search">
    <!--         <input name="Search" type="text" placeholder="Search For a Specific Product" required="" /> -->
              <input type="text" placeholder="Search For a Specific Product" id='searchString' name='searchString' value="<?php echo (isset($_SESSION['searchString']))?trim($_SESSION['searchString'], '%'):''; ?>" />
            
            <!-- <div class="divider"/> -->
        
            <select id="agileinfo_search" data-live-search="true" name='category'>
              <option data-tokens='all' value="all"> All Categories </option>
              <?php

              $sql = "SELECT * FROM utility_category;";
              $result = mysqli_query($conn, $sql);

              while($row = mysqli_fetch_assoc($result)){

            ?>
                <option data-tokens='<?php $row['category_id'] ?>' value='<?php $row['category_id'] ?>'> 
                  <?php echo $row['name'] ?>
                </option>;
            <?php
              }
            ?>
            </select>
                       <!--  <div class="divider"/> -->
            <button type="button" class="btn btn-default" aria-label="Right Align" onclick="filter_result()">
              <i class="fa fa-search" aria-hidden="true"> </i>
            </button>
       
        </div>  
        <div class="clearfix"></div>
      </div>
    </div>
  </header>
  <!-- //header -->
  <!-- Slider -->
    <div class="slider">
      <ul class="rslides" id="slider">
        <li>
          <div class="w3ls-slide-text">
            <h3>Sell or Advertise anything online</h3>
          </div>
        </li>
        <li>
          <div class="w3ls-slide-text">
            <h3>Find the Best Deals Here</h3>
          </div>
        </li>
        <li>
          <div class="w3ls-slide-text">
            <h3>Lets build the home of your dreams</h3>
          </div>
        </li>
        <li>
          <div class="w3ls-slide-text">
            <h3>Find your dream ride</h3>
          </div>
        </li>
      </ul>
    </div>
    <!-- //Slider -->
    <div class="total-ads main-grid-border">
      <div class="container">
          <div class="browse-category">
            <?php
              $sql = "SELECT * FROM utility_category;";
              $result = mysqli_query($conn, $sql);
              while($row = mysqli_fetch_assoc($result)){
            ?>
            <?php
              }
            ?>
            <!-- </select> -->
          </div> 
          <!-- <div class="clearfix"></div> -->
      </div>
    </div>
  
  <?php
  if(isset($_SESSION['category']))
    $category = $_SESSION['category'];
  else
    $category = 'all';

  if(isset($_SESSION['searchString']) and $_SESSION['searchString'] != ""){
    $searchString = $_SESSION['searchString']; 
    $category= 'all';
  }else{
    $searchString = '%';
    // $category= 'all';
  }

  // $message = "We received your Message.";
  //       echo "<script type='text/javascript'>alert('$searchString');</script>";
  //       echo "<script type='text/javascript'>alert('$category');</script>";
  ?>


<?php
    echo '<h1 style="text-align:CENTER; margin-top:15px">Welcome, '.$_SESSION['firstname'].'!</h1>';
?>

<div id = "results">

<div id="product-grid">
  <div class="ads-grid">
        <div class="ads-display col-md-9">
          <div class="wrapper">         
          <div class="bs-example bs-example-tabs" role="tabpanel" data-example-id="togglable-tabs">
            
            <div class="tab-content">
            <div role="tabpanel" class="tab-pane fade in active" id="home" aria-labelledby="home-tab">
              <div>
                <div id="container">
                
                <div class="clearfix"></div>
                <ul class="grid" id="grid">
<?php



  if (isset($_GET["page"])) { $page  = $_GET["page"]; } else { $page=1; };  
    $start_from = ($page-1) * $limit; 

    if($category == 'all'){
      $query = "SELECT * FROM utility WHERE is_deleted <> '1' AND name LIKE '$searchString' ORDER BY timestamp DESC LIMIT $start_from, $limit;";
      $sql = "SELECT COUNT(*) FROM utility WHERE is_deleted <> '1' AND name LIKE '$searchString';";
    }
    else
    {
      // $temp = "%".$searchString."%";
      // echo "<br>".$temp;
      $query = "SELECT * FROM utility WHERE is_deleted <> '1' AND category_id=".$category." AND name LIKE '%%$searchString%%' ORDER BY timestamp DESC LIMIT $start_from, $limit;";  
      $sql = "SELECT COUNT(*) FROM utility WHERE is_deleted <> '1' AND category_id=".$category." AND name LIKE '%%$searchString%%';";
    }

  $result = mysqli_query($conn, $query);

  while($row = mysqli_fetch_assoc($result)){

    $img_res =  mysqli_query($conn, "SELECT image_path FROM utility_image where utility_id=".$row["utility_id"]);
    $path = mysqli_fetch_assoc($img_res);

    $cat_name = mysqli_query($conn, "SELECT name FROM utility_category where category_id=".$row["category_id"]);
    $cat_name_row = mysqli_fetch_assoc($cat_name);

?>
  <!-- <div class="col-md-3">
          <div class="focus-grid w3layouts-boder4">
            <a class="btn-8" href="register.html">
              <div class="focus-border">
                <div class="focus-layout">
                  <div class="focus-image"><i class="fa fa-motorcycle"></i></div>
                  <h4 class="clrchg">Bikes</h4>
                </div>
              </div>
            </a>
          </div>  
          </div> -->

      <li>
          <img src="<?php echo $path["image_path"]; ?>" width="200px" height="200px" title="" alt="" />
          <section class="list-left">
          <h5 class="title"><a href="../php/view-product-details.php?page=<?php echo $page; ?>&utility_id=<?php echo $row["utility_id"]; ?>"> <?php echo $row["name"]; ?> </a></h5>
          <div class="ad-price">
            <?php echo $cat_name_row["name"]; ?></div>
          <div class="ad-price"><?php echo "$".$row["price"]; ?></div>
          </section>
          <section class="list-right">
            <form method="post" action="../php/manage-wishlist.php?action=add&page=<?php echo $page; ?>&utility_id=<?php echo $row["utility_id"]; ?>">
          <div><input type="submit" value="Add to wishlist" class="btn btn-success" /></div>
        </form>
        <?php
    if(isset($_SESSION['isAdmin']) && $_SESSION['isAdmin']==1){
      $_SESSION['delHome']=1
    ?>
        <form method="post" action="../html/edit_utility_form.php?utility_id=<?php echo $row["utility_id"]; ?>">
          <div><input type="submit" value="Edit" class="btn btn-info" /></div></form>

          <form method="post" action="../php/manage-products.php?action=remove&utility_id=<?php echo $row["utility_id"]; ?>">
        <div><input type="submit" value="Remove" class="btn btn-danger" /></div>
      </form>
    <?php } ?>
          </section>
          <div class="clearfix"></div>
        <!-- </form> -->
      </li> 

<?php } ?>

                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

</div>

<?php  
  ///$sql = "SELECT COUNT(*) FROM utility WHERE is_deleted <> '1';";  
  $rs_result = mysqli_query($conn, $sql);  
  
  $row = mysqli_fetch_array($rs_result);  

  $total_records = $row[0];  
  $total_pages = ceil($total_records / $limit);  

  echo "<div margin-bottom>";

  //$pagLink = "<div class='pagination' style ='margin-bottom:20px; margin-left:100px'>";  
  $pagLink = "<ul class='pagination pagination-sm'>";
  for ($i=1; $i<=$total_pages; $i++) {  
             $pagLink .= " "."<li><a href='homepage.php?page=".$i."'>".$i."</a></li>";  
  };  
  echo $pagLink . "</ul>";  

  echo "</div>"
?>

</div>

    <!-- content-starts-here
    <div class="main-content">
      <div class="w3-categories">
        <div class="container">
          <div class="col-md-3">
            <div class="focus-grid w3layouts-boder1">
              <a class="btn-8" href="../categories.html">
                <div class="focus-border">
                  <div class="focus-layout">
                    <div class="focus-image"><i class="fa fa-mobile"></i></div>
                    <h4 class="clrchg">Mobiles</h4>
                  </div>
                </div>
              </a>
            </div>
          </div>
          <div class="col-md-3">
            <div class="focus-grid w3layouts-boder2"> 
            <a class="btn-8" href="../categories.html#parentVerticalTab2">
              <div class="focus-border">
                <div class="focus-layout">
                  <div class="focus-image"><i class="fa fa-laptop"></i></div>
                  <h4 class="clrchg"> Electronics & Appliances</h4>
                </div>
              </div>
            </a>
          </div>
          </div>
          <div class="col-md-3">
          <div class="focus-grid w3layouts-boder3">
            <a class="btn-8" href="../categories.html#parentVerticalTab3">
              <div class="focus-border">
                <div class="focus-layout">
                  <div class="focus-image"><i class="fa fa-car"></i></div>
                  <h4 class="clrchg">Cars</h4>
                </div>
              </div>
            </a>
          </div>  
          </div>
          <div class="col-md-3">
          <div class="focus-grid w3layouts-boder4">
            <a class="btn-8" href="../categories.html#parentVerticalTab4">
              <div class="focus-border">
                <div class="focus-layout">
                  <div class="focus-image"><i class="fa fa-motorcycle"></i></div>
                  <h4 class="clrchg">Bikes</h4>
                </div>
              </div>
            </a>
          </div>  
          </div>
          <div class="col-md-3">
          <div class="focus-grid w3layouts-boder5">
            <a class="btn-8" href="../categories.html#parentVerticalTab5">
              <div class="focus-border">
                <div class="focus-layout">
                  <div class="focus-image"><i class="fa fa-wheelchair"></i></div>
                  <h4 class="clrchg">Furnitures</h4>
                </div>
              </div>
            </a>
          </div>
          </div>
          <div class="col-md-3">
          <div class="focus-grid w3layouts-boder6">
            <a class="btn-8" href="../categories.html#parentVerticalTab6">
              <div class="focus-border">
                <div class="focus-layout">
                  <div class="focus-image"><i class="fa fa-paw"></i></div>
                  <h4 class="clrchg">Pets</h4>
                </div>
              </div>
            </a>
          </div>  
          </div>
          <div class="col-md-3">
          <div class="focus-grid w3layouts-boder7">
            <a class="btn-8" href="../categories.html#parentVerticalTab7">
              <div class="focus-border">
                <div class="focus-layout">
                  <div class="focus-image"><i class="fa fa-book"></i></div>
                  <h4 class="clrchg">Books, Sports & Hobbies</h4>
                </div>
              </div>
            </a>
          </div>  
          </div>
          <div class="col-md-3">
          <div class="focus-grid w3layouts-boder8">
            <a class="btn-8" href="../categories.html#parentVerticalTab8">
              <div class="focus-border">
                <div class="focus-layout">
                  <div class="focus-image"><i class="fa fa-asterisk"></i></div>
                  <h4 class="clrchg">Fashion</h4>
                </div>
              </div>
            </a>
          </div>  
          </div>
          <div class="col-md-3">
          <div class="focus-grid w3layouts-boder9">
            <a class="btn-8" href="../categories.html#parentVerticalTab9">
              <div class="focus-border">
                <div class="focus-layout">
                  <div class="focus-image"><i class="fa fa-gamepad"></i></div>
                  <h4 class="clrchg">Kids</h4>
                </div>
              </div>
            </a>
          </div>  
          </div>
          <div class="col-md-3">
          <div class="focus-grid w3layouts-boder10">
            <a class="btn-8" href="../categories.html#parentVerticalTab10">
              <div class="focus-border">
                <div class="focus-layout">
                  <div class="focus-image"><i class="fa fa-shield"></i></div>
                  <h4 class="clrchg">Services</h4>
                </div>
              </div>
            </a>
          </div>
          </div>
          <div class="col-md-3">
          <div class="focus-grid w3layouts-boder11">
            <a class="btn-8" href="../categories.html#parentVerticalTab11">
              <div class="focus-border">
                <div class="focus-layout">
                  <div class="focus-image"><i class="fa fa-at"></i></div>
                  <h4 class="clrchg">Jobs</h4>
                </div>
              </div>
            </a>
          </div>
          </div>
          <div class="col-md-3">
          <div class="focus-grid w3layouts-boder12">
            <a class="btn-8" href="../categories.html#parentVerticalTab12">
              <div class="focus-border">
                <div class="focus-layout">
                  <div class="focus-image"><i class="fa fa-home"></i></div>
                  <h4 class="clrchg">Real Estate</h4>
                </div>
              </div>
            </a>
          </div>
          </div>
          <div class="clearfix"></div>
        </div>
      </div>
       -->
      </div>
      <!--partners-->
      <div class="w3layouts-partners">
        <h3>Our Partners</h3>
          <div class="container">
            <ul>
              <li><a href="#"><img class="img-responsive" src="../images/p-1.png" alt=""></a></li>
              <li><a href="#"><img class="img-responsive" src="../images/p-2.png" alt=""></a></li>
              <li><a href="#"><img class="img-responsive" src="../images/p-3.png" alt=""></a></li>
              <li><a href="#"><img class="img-responsive" src="../images/p-4.png" alt=""></a></li>
              <li><a href="#"><img class="img-responsive" src="../images/p-5.png" alt=""></a></li>
              <li><a href="#"><img class="img-responsive" src="../images/p-6.png" alt=""></a></li>
              <li><a href="#"><img class="img-responsive" src="../images/p-7.png" alt=""></a></li>
              <li><a href="#"><img class="img-responsive" src="../images/p-8.png" alt=""></a></li>
              <li><a href="#"><img class="img-responsive" src="../images/p-9.png" alt=""></a></li>
              <li><a href="#"><img class="img-responsive" src="../images/p-10.png" alt=""></a></li>  
            </ul>
          </div>
        </div>  

    </div>
    <!--footer section start-->   
<footer>
      <div class="w3-agileits-footer-top">
        <div class="container">
          <div class="wthree-foo-grids">
            <div class="col-md-3 wthree-footer-grid">
              <h4 class="footer-head">Who We Are</h4>
              <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.</p>
              <p>The point of using Lorem Ipsum is that it has a more-or-less normal letters, as opposed to using 'Content here.</p>
            </div>
            <div class="col-md-3 wthree-footer-grid">
              <h4 class="footer-head">Help</h4>
              <ul>
                <li><a href="howitworks.html"><i class="fa fa-long-arrow-right" aria-hidden="true"></i>How it Works</a></li>            
                <li><a href="sitemap.html"><i class="fa fa-long-arrow-right" aria-hidden="true"></i>Sitemap</a></li>
                <li><a href="faq.html"><i class="fa fa-long-arrow-right" aria-hidden="true"></i>Faq</a></li>
                <li><a href="feedback.html"><i class="fa fa-long-arrow-right" aria-hidden="true"></i>Feedback</a></li>
                <li><a href="contact.html"><i class="fa fa-long-arrow-right" aria-hidden="true"></i>Contact</a></li>
                <li><a href="typography.html"><i class="fa fa-long-arrow-right" aria-hidden="true"></i>Short codes</a></li>
                <li><a href="icons.html"><i class="fa fa-long-arrow-right" aria-hidden="true"></i>Icons Page</a></li>
              </ul>
            </div>
            <div class="col-md-3 wthree-footer-grid">
              <h4 class="footer-head">Information</h4>
              <ul>
                <li><a href="regions.html"><i class="fa fa-long-arrow-right" aria-hidden="true"></i>Locations Map</a></li>  
                <li><a href="terms.html"><i class="fa fa-long-arrow-right" aria-hidden="true"></i>Terms of Use</a></li>
                <li><a href="popular-search.html"><i class="fa fa-long-arrow-right" aria-hidden="true"></i>Popular searches</a></li>  
                <li><a href="privacy.html"><i class="fa fa-long-arrow-right" aria-hidden="true"></i>Privacy Policy</a></li> 
              </ul>
            </div>
            <div class="col-md-3 wthree-footer-grid">
              <h4 class="footer-head">Contact Us</h4>
              <span class="hq">Our headquarters</span>
              <address>
                <ul class="location">
                  <li><span class="glyphicon glyphicon-map-marker"></span></li>
                  <li>CENTER FOR FINANCIAL ASSISTANCE TO DEPOSED NIGERIAN ROYALTY</li>
                </ul> 
                <div class="clearfix"> </div>
                <ul class="location">
                  <li><span class="glyphicon glyphicon-earphone"></span></li>
                  <li>+0 561 111 235</li>
                </ul> 
                <div class="clearfix"> </div>
                <ul class="location">
                  <li><span class="glyphicon glyphicon-envelope"></span></li>
                  <li><a href="mailto:info@example.com">mail@example.com</a></li>
                </ul>           
              </address>
            </div>
            <div class="clearfix"></div>
          </div>            
        </div>  
      </div>  
      <div class="agileits-footer-bottom text-center">
      <div class="container">
        <div class="w3-footer-logo">
          <h1><a href="index.html"><img src = "bns.png"></a></h1>
        </div>
        <div class="w3-footer-social-icons">
          <ul>
            <li><a class="facebook" href="#"><i class="fa fa-facebook" aria-hidden="true"></i><span>Facebook</span></a></li>
            <li><a class="twitter" href="#"><i class="fa fa-twitter" aria-hidden="true"></i><span>Twitter</span></a></li>
            <li><a class="flickr" href="#"><i class="fa fa-flickr" aria-hidden="true"></i><span>Flickr</span></a></li>
            <li><a class="googleplus" href="#"><i class="fa fa-google-plus" aria-hidden="true"></i><span>Google+</span></a></li>
            <li><a class="dribbble" href="#"><i class="fa fa-dribbble" aria-hidden="true"></i><span>Dribbble</span></a></li>
          </ul>
        </div>
        <div class="copyrights">
          <p> © 2019 BnS. All Rights Reserved</p>
        </div>
        <div class="clearfix"></div>
      </div>
    </div>
    </footer>
        <!--footer section end-->
    <!-- Navigation-Js-->
      <script type="text/javascript" src="../js/main.js"></script>
      <script type="text/javascript" src="../js/classie.js"></script>
    <!-- //Navigation-Js-->
    <!-- js -->
    <script type="text/javascript" src="../js/jquery.min.js"></script>
    <!-- js -->
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="../js/bootstrap.js"></script>
    <script src="../js/bootstrap-select.js"></script>
    <script>
      $(document).ready(function () {
      var mySelect = $('#first-disabled2');

      $('#special').on('click', function () {
        mySelect.find('option:selected').prop('disabled', true);
        mySelect.selectpicker('refresh');
      });

      $('#special2').on('click', function () {
        mySelect.find('option:disabled').prop('disabled', false);
        mySelect.selectpicker('refresh');
      });

      $('#basic2').selectpicker({
        liveSearch: true,
        maxOptions: 1
      });
      });
    </script>
    <!-- language-select -->
    <script type="text/javascript" src="../js/jquery.leanModal.min.js"></script>
    <link href="../css/jquery.uls.css" rel="stylesheet"/>
    <link href="../css/jquery.uls.grid.css" rel="stylesheet"/>
    <link href="../css/jquery.uls.lcd.css" rel="stylesheet"/>
    <!-- Source -->
    <script src="../js/jquery.uls.data.js"></script>
    <script src="../js/jquery.uls.data.utils.js"></script>
    <script src="../js/jquery.uls.lcd.js"></script>
    <script src="../js/jquery.uls.languagefilter.js"></script>
    <script src="../js/jquery.uls.regionfilter.js"></script>
    <script src="../js/jquery.uls.core.js"></script>
    <script>
          $( document ).ready( function() {
            $( '.uls-trigger' ).uls( {
              onSelect : function( language ) {
                var languageName = $.uls.data.getAutonym( language );
                $( '.uls-trigger' ).text( languageName );
              },
              quickList: ['en', 'hi', 'he', 'ml', 'ta', 'fr'] //FIXME
            } );
          } );
        </script>
    <!-- //language-select -->
    <script type="text/javascript" src="../js/jquery.flexisel.js"></script><!-- flexisel-js -->  
          <script type="text/javascript">
             $(window).load(function() {
              $("#flexiselDemo3").flexisel({
                visibleItems:1,
                animationSpeed: 1000,
                autoPlay: true,
                autoPlaySpeed: 5000,        
                pauseOnHover: true,
                enableResponsiveBreakpoints: true,
                responsiveBreakpoints: { 
                  portrait: { 
                    changePoint:480,
                    visibleItems:1
                  }, 
                  landscape: { 
                    changePoint:640,
                    visibleItems:1
                  },
                  tablet: { 
                    changePoint:768,
                    visibleItems:1
                  }
                }
              });
              
            });
             </script>
    <!-- Slider-JavaScript -->
      <script src="../js/responsiveslides.min.js"></script>  
       <script>
      $(function () { 
        $("#slider").responsiveSlides({
        auto: true,
        pager: false,
        nav: true,
        speed: 500,
        maxwidth: 800,
        namespace: "large-btns"
        });

      });
      </script>
    <!-- //Slider-JavaScript -->
    <!-- here stars scrolling icon -->
      <script type="text/javascript">
        $(document).ready(function() {
          /*
            var defaults = {
            containerID: 'toTop', // fading element id
            containerHoverID: 'toTopHover', // fading element hover id
            scrollSpeed: 1200,
            easingType: 'linear' 
            };
          */
                    
          $().UItoTop({ easingType: 'easeOutQuart' });
                    
          });
      </script>
      <!-- start-smoth-scrolling -->
      <script type="text/javascript" src="../js/move-top.js"></script>
      <script type="text/javascript" src="../js/easing.js"></script>
      <script type="text/javascript">
        jQuery(document).ready(function($) {
          $(".scroll").click(function(event){   
            event.preventDefault();
            $('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
          });
        });
      </script>
      <!-- start-smoth-scrolling -->
    <!-- //here ends scrolling icon -->
</body>   
</html>